import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Breadcrumbs/Breadcrumbs.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/Breadcrumbs/Breadcrumbs.module.css";
import { NavLink, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
import ARROW_ICON from "/src/assets/arrow.svg?import";
import { CATEGORIES, GENDERS } from "/src/constants/categories.js";
export function Breadcrumbs() {
  _s();
  const {
    gender,
    category,
    subcategory
  } = useParams();
  console.log(gender, category, subcategory);
  const foundGender = GENDERS.find((g) => g.path === gender);
  const foundCategory = CATEGORIES.find((c) => c.path === category);
  const breadcrumbs = [{
    categoryName: foundGender.categoryName,
    path: `/${foundGender.path}`
  }, {
    categoryName: foundCategory.categoryName,
    path: `/${foundGender.path}/${foundCategory.path}`
  }];
  if (subcategory) {
    const foundSubcategory = foundCategory.subcategories.find((sc) => sc.path === subcategory);
    breadcrumbs.push({
      categoryName: foundSubcategory.categoryName,
      path: `/${foundGender.path}/${foundCategory.path}/${foundSubcategory.path}`
    });
  }
  return /* @__PURE__ */ jsxDEV("ul", { className: styles.breadcrumbs, children: breadcrumbs.map((breadcrumb) => {
    return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(NavLink, { end: true, to: breadcrumb.path, children: [
      breadcrumb.categoryName,
      /* @__PURE__ */ jsxDEV("img", { src: ARROW_ICON }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.jsx",
        lineNumber: 35,
        columnNumber: 29
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.jsx",
      lineNumber: 33,
      columnNumber: 25
    }, this) }, breadcrumb.path, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.jsx",
      lineNumber: 32,
      columnNumber: 14
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.jsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
}
_s(Breadcrumbs, "QDePq4RL5yZfUYoD81ndmNrpNu0=", false, function() {
  return [useParams];
});
_c = Breadcrumbs;
var _c;
$RefreshReg$(_c, "Breadcrumbs");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUM0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6QzVCLE9BQU9BLFlBQVk7QUFDbkIsU0FBU0MsU0FBU0MsaUJBQWlCO0FBQ25DLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyxZQUFZQyxlQUFlO0FBRTdCLGdCQUFTQyxjQUFjO0FBQUFDLEtBQUE7QUFDMUIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVVDO0FBQUFBLEVBQVksSUFBSVIsVUFBVTtBQUNwRFMsVUFBUUMsSUFBSUosUUFBUUMsVUFBVUMsV0FBVztBQUV6QyxRQUFNRyxjQUFjUixRQUFRUyxLQUFNQyxPQUFNQSxFQUFFQyxTQUFTUixNQUFNO0FBQ3pELFFBQU1TLGdCQUFnQmIsV0FBV1UsS0FBTUksT0FBTUEsRUFBRUYsU0FBU1AsUUFBUTtBQUVoRSxRQUFNVSxjQUFjLENBQ2hCO0FBQUEsSUFDSUMsY0FBY1AsWUFBWU87QUFBQUEsSUFDMUJKLE1BQU8sSUFBR0gsWUFBWUcsSUFBSztBQUFBLEVBQy9CLEdBQ0E7QUFBQSxJQUNJSSxjQUFjSCxjQUFjRztBQUFBQSxJQUM1QkosTUFBTyxJQUFHSCxZQUFZRyxJQUFLLElBQUdDLGNBQWNELElBQUs7QUFBQSxFQUNyRCxDQUFDO0FBR0wsTUFBSU4sYUFBYTtBQUNiLFVBQU1XLG1CQUFtQkosY0FBY0ssY0FBY1IsS0FDaERTLFFBQU9BLEdBQUdQLFNBQVNOLFdBQ3hCO0FBRUFTLGdCQUFZSyxLQUFLO0FBQUEsTUFDYkosY0FBY0MsaUJBQWlCRDtBQUFBQSxNQUMvQkosTUFBTyxJQUFHSCxZQUFZRyxJQUFLLElBQUdDLGNBQWNELElBQUssSUFBR0ssaUJBQWlCTCxJQUFLO0FBQUEsSUFDOUUsQ0FBQztBQUFBLEVBQ0w7QUFFQSxTQUNJLHVCQUFDLFFBQUcsV0FBV2hCLE9BQU9tQixhQUNqQkEsc0JBQVlNLElBQUtDLGdCQUFlO0FBQzdCLFdBQ0ksdUJBQUMsUUFDRyxpQ0FBQyxXQUFRLEtBQUcsTUFBQyxJQUFJQSxXQUFXVixNQUN2QlU7QUFBQUEsaUJBQVdOO0FBQUFBLE1BQ1osdUJBQUMsU0FBSSxLQUFLakIsY0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCO0FBQUEsU0FGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLEtBSkt1QixXQUFXVixNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVSLENBQUMsS0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFUjtBQUFDVCxHQTNDZUQsYUFBVztBQUFBLFVBQ21CSixTQUFTO0FBQUE7QUFBQXlCLEtBRHZDckI7QUFBVyxJQUFBcUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlcyIsIk5hdkxpbmsiLCJ1c2VQYXJhbXMiLCJBUlJPV19JQ09OIiwiQ0FURUdPUklFUyIsIkdFTkRFUlMiLCJCcmVhZGNydW1icyIsIl9zIiwiZ2VuZGVyIiwiY2F0ZWdvcnkiLCJzdWJjYXRlZ29yeSIsImNvbnNvbGUiLCJsb2ciLCJmb3VuZEdlbmRlciIsImZpbmQiLCJnIiwicGF0aCIsImZvdW5kQ2F0ZWdvcnkiLCJjIiwiYnJlYWRjcnVtYnMiLCJjYXRlZ29yeU5hbWUiLCJmb3VuZFN1YmNhdGVnb3J5Iiwic3ViY2F0ZWdvcmllcyIsInNjIiwicHVzaCIsIm1hcCIsImJyZWFkY3J1bWIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJyZWFkY3J1bWJzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0JyZWFkY3J1bWJzLm1vZHVsZS5jc3NcIjtcbmltcG9ydCB7IE5hdkxpbmssIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgQVJST1dfSUNPTiBmcm9tIFwiLi4vLi4vYXNzZXRzL2Fycm93LnN2Z1wiO1xuaW1wb3J0IHsgQ0FURUdPUklFUywgR0VOREVSUyB9IGZyb20gXCIuLi8uLi9jb25zdGFudHMvY2F0ZWdvcmllc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gQnJlYWRjcnVtYnMoKSB7XG4gICAgY29uc3QgeyBnZW5kZXIsIGNhdGVnb3J5LCBzdWJjYXRlZ29yeSB9ID0gdXNlUGFyYW1zKCk7XG4gICAgY29uc29sZS5sb2coZ2VuZGVyLCBjYXRlZ29yeSwgc3ViY2F0ZWdvcnkpO1xuXG4gICAgY29uc3QgZm91bmRHZW5kZXIgPSBHRU5ERVJTLmZpbmQoKGcpID0+IGcucGF0aCA9PT0gZ2VuZGVyKTtcbiAgICBjb25zdCBmb3VuZENhdGVnb3J5ID0gQ0FURUdPUklFUy5maW5kKChjKSA9PiBjLnBhdGggPT09IGNhdGVnb3J5KTtcblxuICAgIGNvbnN0IGJyZWFkY3J1bWJzID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICBjYXRlZ29yeU5hbWU6IGZvdW5kR2VuZGVyLmNhdGVnb3J5TmFtZSxcbiAgICAgICAgICAgIHBhdGg6IGAvJHtmb3VuZEdlbmRlci5wYXRofWAsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIGNhdGVnb3J5TmFtZTogZm91bmRDYXRlZ29yeS5jYXRlZ29yeU5hbWUsXG4gICAgICAgICAgICBwYXRoOiBgLyR7Zm91bmRHZW5kZXIucGF0aH0vJHtmb3VuZENhdGVnb3J5LnBhdGh9YCxcbiAgICAgICAgfSxcbiAgICBdO1xuXG4gICAgaWYgKHN1YmNhdGVnb3J5KSB7XG4gICAgICAgIGNvbnN0IGZvdW5kU3ViY2F0ZWdvcnkgPSBmb3VuZENhdGVnb3J5LnN1YmNhdGVnb3JpZXMuZmluZChcbiAgICAgICAgICAgIChzYykgPT4gc2MucGF0aCA9PT0gc3ViY2F0ZWdvcnlcbiAgICAgICAgKTtcblxuICAgICAgICBicmVhZGNydW1icy5wdXNoKHtcbiAgICAgICAgICAgIGNhdGVnb3J5TmFtZTogZm91bmRTdWJjYXRlZ29yeS5jYXRlZ29yeU5hbWUsXG4gICAgICAgICAgICBwYXRoOiBgLyR7Zm91bmRHZW5kZXIucGF0aH0vJHtmb3VuZENhdGVnb3J5LnBhdGh9LyR7Zm91bmRTdWJjYXRlZ29yeS5wYXRofWAsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDx1bCBjbGFzc05hbWU9e3N0eWxlcy5icmVhZGNydW1ic30+XG4gICAgICAgICAgICB7YnJlYWRjcnVtYnMubWFwKChicmVhZGNydW1iKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17YnJlYWRjcnVtYi5wYXRofT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIGVuZCB0bz17YnJlYWRjcnVtYi5wYXRofT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnJlYWRjcnVtYi5jYXRlZ29yeU5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e0FSUk9XX0lDT059IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICA8L3VsPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvQnJlYWRjcnVtYnMvQnJlYWRjcnVtYnMuanN4In0=