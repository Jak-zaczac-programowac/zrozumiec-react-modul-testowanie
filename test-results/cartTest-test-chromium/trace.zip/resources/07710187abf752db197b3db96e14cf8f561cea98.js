import {
  require_react
} from "/node_modules/.vite/deps/chunk-WUJDOWEQ.js?v=6c826b96";
export default require_react();
//# sourceMappingURL=react.js.map
