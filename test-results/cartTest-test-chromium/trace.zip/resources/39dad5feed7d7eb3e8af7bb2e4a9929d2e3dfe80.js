import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MainMenu/MainMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainMenu/MainMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/MainMenu/MainMenu.module.css";
import { GENDERS } from "/src/constants/categories.js";
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
export function MainMenu() {
  return /* @__PURE__ */ jsxDEV("ul", { className: styles.mainMenu, children: GENDERS.map((category) => {
    return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(NavLink, { to: category.path, children: category.categoryName }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainMenu/MainMenu.jsx",
      lineNumber: 8,
      columnNumber: 25
    }, this) }, category.path, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainMenu/MainMenu.jsx",
      lineNumber: 7,
      columnNumber: 14
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainMenu/MainMenu.jsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = MainMenu;
var _c;
$RefreshReg$(_c, "MainMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainMenu/MainMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCO0FBVnhCLE9BQU9BLG9CQUFZO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFFakIsZ0JBQVNDLFdBQVc7QUFDdkIsU0FDSSx1QkFBQyxRQUFHLFdBQVdILE9BQU9JLFVBQ2pCSCxrQkFBUUksSUFBS0MsY0FBYTtBQUN2QixXQUNJLHVCQUFDLFFBQ0csaUNBQUMsV0FBUSxJQUFJQSxTQUFTQyxNQUNqQkQsbUJBQVNFLGdCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhLRixTQUFTQyxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVSLENBQUMsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFUjtBQUFDRSxLQWRlTjtBQUFRLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJzdHlsZXMiLCJHRU5ERVJTIiwiTmF2TGluayIsIk1haW5NZW51IiwibWFpbk1lbnUiLCJtYXAiLCJjYXRlZ29yeSIsInBhdGgiLCJjYXRlZ29yeU5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1haW5NZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL01haW5NZW51Lm1vZHVsZS5jc3NcIjtcbmltcG9ydCB7IEdFTkRFUlMgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL2NhdGVnb3JpZXNcIjtcbmltcG9ydCB7IE5hdkxpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gTWFpbk1lbnUoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPHVsIGNsYXNzTmFtZT17c3R5bGVzLm1haW5NZW51fT5cbiAgICAgICAgICAgIHtHRU5ERVJTLm1hcCgoY2F0ZWdvcnkpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtjYXRlZ29yeS5wYXRofT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIHRvPXtjYXRlZ29yeS5wYXRofT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuY2F0ZWdvcnlOYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgPC91bD5cbiAgICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMva2FjcGVyc29rb2xvd3NraS9kZXYvcmVhY3QtY291cnNlL3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL01haW5NZW51L01haW5NZW51LmpzeCJ9