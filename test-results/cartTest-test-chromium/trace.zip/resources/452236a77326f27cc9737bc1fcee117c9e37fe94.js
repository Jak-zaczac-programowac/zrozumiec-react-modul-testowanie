import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Layout/Layout.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
import { CategoryMenu } from "/src/components/CategoryMenu/CategoryMenu.jsx";
import { CurrencySelector } from "/src/components/CurrencySelector/CurrencySelector.jsx";
import { Footer } from "/src/components/Footer/Footer.jsx";
import { IconMenu } from "/src/components/IconMenu/IconMenu.jsx";
import { Logo } from "/src/components/Logo/Logo.jsx";
import { MainContent } from "/src/components/MainContent/MainContent.jsx";
import { MainMenu } from "/src/components/MainMenu/MainMenu.jsx";
import { TopBar } from "/src/components/TopBar/TopBar.jsx";
import { CurrencyContext } from "/src/contexts/CurrencyContext.js";
import __vite__cjsImport13_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useState = __vite__cjsImport13_react["useState"];
import { CURRENCIES } from "/src/constants/currencies.js";
import { CartContext } from "/src/contexts/CartContext.js";
import { useLocalStorage } from "/src/hooks/useLocalStorage.js";
export function Layout() {
  _s();
  const [currency, setCurrency] = useLocalStorage("selected_currency", CURRENCIES.PLN);
  const [cartItems, setCartItems] = useLocalStorage("cart_products", []);
  function addProductToCart(product) {
    const newState = [...cartItems, product];
    setCartItems(newState);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(CartContext.Provider, { value: [cartItems, addProductToCart], children: /* @__PURE__ */ jsxDEV(CurrencyContext.Provider, { value: [currency, setCurrency], children: [
    /* @__PURE__ */ jsxDEV(MainContent, { children: [
      /* @__PURE__ */ jsxDEV(TopBar, { children: [
        /* @__PURE__ */ jsxDEV(MainMenu, {}, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
          lineNumber: 29,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
          lineNumber: 30,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(CurrencySelector, {}, void 0, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
            lineNumber: 32,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(IconMenu, {}, void 0, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
            lineNumber: 33,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
          lineNumber: 31,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
        lineNumber: 28,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV(CategoryMenu, {}, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
        lineNumber: 36,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
        lineNumber: 37,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
      lineNumber: 27,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
      lineNumber: 39,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
    lineNumber: 26,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
    lineNumber: 25,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
}
_s(Layout, "vAW3iJ1QV4A/RFgUX8tjgh4mGJo=", false, function() {
  return [useLocalStorage, useLocalStorage];
});
_c = Layout;
var _c;
$RefreshReg$(_c, "Layout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Layout/Layout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJRLG1CQUtvQixjQUxwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3QlIsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx1QkFBdUI7QUFFekIsZ0JBQVNDLFNBQVM7QUFBQUMsS0FBQTtBQUNyQixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUosZ0JBQzVCLHFCQUNBRixXQUFXTyxHQUNmO0FBRUEsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlQLGdCQUFnQixpQkFBaUIsRUFBRTtBQUVyRSxXQUFTUSxpQkFBaUJDLFNBQVM7QUFDL0IsVUFBTUMsV0FBVyxDQUFDLEdBQUdKLFdBQVdHLE9BQU87QUFDdkNGLGlCQUFhRyxRQUFRO0FBQUEsRUFDekI7QUFFQSxTQUNJLG1DQUNJLGlDQUFDLFlBQVksVUFBWixFQUFxQixPQUFPLENBQUNKLFdBQVdFLGdCQUFnQixHQUNyRCxpQ0FBQyxnQkFBZ0IsVUFBaEIsRUFBeUIsT0FBTyxDQUFDTCxVQUFVQyxXQUFXLEdBQ25EO0FBQUEsMkJBQUMsZUFDRztBQUFBLDZCQUFDLFVBQ0c7QUFBQSwrQkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUztBQUFBLFFBQ1QsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxRQUNMLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQjtBQUFBLFVBQ2pCLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUztBQUFBLGFBRmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYTtBQUFBLE1BQ2IsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU87QUFBQSxTQVZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0EsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxPQWJYO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQSxLQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkEsS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVSO0FBQUNGLEdBbENlRCxRQUFNO0FBQUEsVUFDY0QsaUJBS0VBLGVBQWU7QUFBQTtBQUFBVyxLQU5yQ1Y7QUFBTSxJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiT3V0bGV0IiwiQ2F0ZWdvcnlNZW51IiwiQ3VycmVuY3lTZWxlY3RvciIsIkZvb3RlciIsIkljb25NZW51IiwiTG9nbyIsIk1haW5Db250ZW50IiwiTWFpbk1lbnUiLCJUb3BCYXIiLCJDdXJyZW5jeUNvbnRleHQiLCJ1c2VTdGF0ZSIsIkNVUlJFTkNJRVMiLCJDYXJ0Q29udGV4dCIsInVzZUxvY2FsU3RvcmFnZSIsIkxheW91dCIsIl9zIiwiY3VycmVuY3kiLCJzZXRDdXJyZW5jeSIsIlBMTiIsImNhcnRJdGVtcyIsInNldENhcnRJdGVtcyIsImFkZFByb2R1Y3RUb0NhcnQiLCJwcm9kdWN0IiwibmV3U3RhdGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxheW91dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT3V0bGV0IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IENhdGVnb3J5TWVudSB9IGZyb20gXCIuLi9DYXRlZ29yeU1lbnUvQ2F0ZWdvcnlNZW51XCI7XG5pbXBvcnQgeyBDdXJyZW5jeVNlbGVjdG9yIH0gZnJvbSBcIi4uL0N1cnJlbmN5U2VsZWN0b3IvQ3VycmVuY3lTZWxlY3RvclwiO1xuaW1wb3J0IHsgRm9vdGVyIH0gZnJvbSBcIi4uL0Zvb3Rlci9Gb290ZXJcIjtcbmltcG9ydCB7IEljb25NZW51IH0gZnJvbSBcIi4uL0ljb25NZW51L0ljb25NZW51XCI7XG5pbXBvcnQgeyBMb2dvIH0gZnJvbSBcIi4uL0xvZ28vTG9nb1wiO1xuaW1wb3J0IHsgTWFpbkNvbnRlbnQgfSBmcm9tIFwiLi4vTWFpbkNvbnRlbnQvTWFpbkNvbnRlbnRcIjtcbmltcG9ydCB7IE1haW5NZW51IH0gZnJvbSBcIi4uL01haW5NZW51L01haW5NZW51XCI7XG5pbXBvcnQgeyBUb3BCYXIgfSBmcm9tIFwiLi4vVG9wQmFyL1RvcEJhclwiO1xuaW1wb3J0IHsgQ3VycmVuY3lDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0N1cnJlbmN5Q29udGV4dFwiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENVUlJFTkNJRVMgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL2N1cnJlbmNpZXNcIjtcbmltcG9ydCB7IENhcnRDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0NhcnRDb250ZXh0XCI7XG5pbXBvcnQgeyB1c2VMb2NhbFN0b3JhZ2UgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlTG9jYWxTdG9yYWdlXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBMYXlvdXQoKSB7XG4gICAgY29uc3QgW2N1cnJlbmN5LCBzZXRDdXJyZW5jeV0gPSB1c2VMb2NhbFN0b3JhZ2UoXG4gICAgICAgIFwic2VsZWN0ZWRfY3VycmVuY3lcIixcbiAgICAgICAgQ1VSUkVOQ0lFUy5QTE5cbiAgICApO1xuXG4gICAgY29uc3QgW2NhcnRJdGVtcywgc2V0Q2FydEl0ZW1zXSA9IHVzZUxvY2FsU3RvcmFnZShcImNhcnRfcHJvZHVjdHNcIiwgW10pO1xuXG4gICAgZnVuY3Rpb24gYWRkUHJvZHVjdFRvQ2FydChwcm9kdWN0KSB7XG4gICAgICAgIGNvbnN0IG5ld1N0YXRlID0gWy4uLmNhcnRJdGVtcywgcHJvZHVjdF07XG4gICAgICAgIHNldENhcnRJdGVtcyhuZXdTdGF0ZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxDYXJ0Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17W2NhcnRJdGVtcywgYWRkUHJvZHVjdFRvQ2FydF19PlxuICAgICAgICAgICAgICAgIDxDdXJyZW5jeUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e1tjdXJyZW5jeSwgc2V0Q3VycmVuY3ldfT5cbiAgICAgICAgICAgICAgICAgICAgPE1haW5Db250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvcEJhcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWFpbk1lbnUgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9nbyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDdXJyZW5jeVNlbGVjdG9yIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uTWVudSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Ub3BCYXI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2F0ZWdvcnlNZW51IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8T3V0bGV0IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvTWFpbkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxGb290ZXIgLz5cbiAgICAgICAgICAgICAgICA8L0N1cnJlbmN5Q29udGV4dC5Qcm92aWRlcj5cbiAgICAgICAgICAgIDwvQ2FydENvbnRleHQuUHJvdmlkZXI+XG4gICAgICAgIDwvPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvTGF5b3V0L0xheW91dC5qc3gifQ==