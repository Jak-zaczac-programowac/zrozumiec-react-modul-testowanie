import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CategoryMenu/CategoryMenu.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.module.css"
const __vite__css = "._categoryMenu_5a167_1 {\n    background-color: var(--color-theme-main);\n    width: 100%;\n}\n\n._categoryMenu_5a167_1 ul {\n    width: 100%;\n    max-width: 100rem;\n    margin: 0 auto;\n    padding: 1rem;\n    display: flex;\n    gap: 1rem;\n}\n\n._categoryMenu_5a167_1 ul li a {\n    color: var(--color-white);\n}\n\n._categoryMenu_5a167_1 ul li a.active {\n    text-decoration: underline;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const categoryMenu = "_categoryMenu_5a167_1";
export default {
	categoryMenu: categoryMenu
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))