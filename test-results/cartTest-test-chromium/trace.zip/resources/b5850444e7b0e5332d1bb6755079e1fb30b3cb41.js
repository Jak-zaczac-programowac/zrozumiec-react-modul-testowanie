import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TopBar/TopBar.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/TopBar/TopBar.module.css"
const __vite__css = "._topBar_16wng_1 {\n    display: grid;\n    grid-template-columns: 1fr 1fr 1fr;\n    width: 100%;\n    max-width: 100rem;\n    margin: 0 auto;\n    align-items: center;\n}\n\n._topBar_16wng_1 > div {\n    display: flex;\n    justify-content: flex-end;\n    align-items: center;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const topBar = "_topBar_16wng_1";
export default {
	topBar: topBar
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))