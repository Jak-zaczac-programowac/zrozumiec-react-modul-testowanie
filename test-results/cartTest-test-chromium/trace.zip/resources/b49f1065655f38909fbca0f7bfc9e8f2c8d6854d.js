import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Accordion/Accordion.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.module.css"
const __vite__css = "._item_1lw2c_1 {\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    padding: 1rem 0;\n    border-bottom: 1px solid var(--color-text-grey);\n    font-weight: 700;\n    cursor: pointer;\n}\n\n._item_1lw2c_1 + p {\n    margin-top: 0.5rem;\n}\n\n._expanded_1lw2c_15 {\n    transform: rotate(180deg);\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const item = "_item_1lw2c_1";
export const expanded = "_expanded_1lw2c_15";
export default {
	item: item,
	expanded: expanded
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))