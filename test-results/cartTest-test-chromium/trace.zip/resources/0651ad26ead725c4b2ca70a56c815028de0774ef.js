import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FullWidthButton/FullWidthButton.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FullWidthButton/FullWidthButton.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/FullWidthButton/FullWidthButton.module.css";
export function FullWidthButton({
  children,
  onClick,
  isBlack
}) {
  return /* @__PURE__ */ jsxDEV("button", { className: `${styles.button} ${isBlack ? styles.black : ""}`, onClick, children }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FullWidthButton/FullWidthButton.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = FullWidthButton;
var _c;
$RefreshReg$(_c, "FullWidthButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FullWidthButton/FullWidthButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSVE7QUFKUixPQUFPQSxvQkFBWTtBQUFBLE1BQThCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUxQyxnQkFBU0MsZ0JBQWdCO0FBQUEsRUFBRUM7QUFBQUEsRUFBVUM7QUFBQUEsRUFBU0M7QUFBUSxHQUFHO0FBQzVELFNBQ0ksdUJBQUMsWUFDRyxXQUFZLEdBQUVKLE9BQU9LLE1BQU8sSUFBR0QsVUFBVUosT0FBT00sUUFBUSxFQUFHLElBQzNELFNBRUNKLFlBSkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRVI7QUFBQ0ssS0FUZU47QUFBZSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiRnVsbFdpZHRoQnV0dG9uIiwiY2hpbGRyZW4iLCJvbkNsaWNrIiwiaXNCbGFjayIsImJ1dHRvbiIsImJsYWNrIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGdWxsV2lkdGhCdXR0b24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vRnVsbFdpZHRoQnV0dG9uLm1vZHVsZS5jc3NcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEZ1bGxXaWR0aEJ1dHRvbih7IGNoaWxkcmVuLCBvbkNsaWNrLCBpc0JsYWNrIH0pIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9e2Ake3N0eWxlcy5idXR0b259ICR7aXNCbGFjayA/IHN0eWxlcy5ibGFjayA6IFwiXCJ9YH1cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICAgID5cbiAgICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3JlYWN0LWNvdXJzZS96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9GdWxsV2lkdGhCdXR0b24vRnVsbFdpZHRoQnV0dG9uLmpzeCJ9