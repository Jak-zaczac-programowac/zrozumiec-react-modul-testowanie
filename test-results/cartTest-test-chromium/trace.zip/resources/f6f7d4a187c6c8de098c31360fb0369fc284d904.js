import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Price/Price.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Price/Price.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useContext = __vite__cjsImport3_react["useContext"];
import { CurrencyContext } from "/src/contexts/CurrencyContext.js";
import { CURRENCIES, CURRENCY_SIGN } from "/src/constants/currencies.js";
export function Price({
  product
}) {
  _s();
  const [currency] = useContext(CurrencyContext);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    currency === CURRENCIES.PLN ? product.pricePLN : product.priceUSD,
    CURRENCY_SIGN[currency]
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Price/Price.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(Price, "ZbDfdLMxfWGE+8eHwtZKYbUXdY8=");
_c = Price;
var _c;
$RefreshReg$(_c, "Price");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Price/Price.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBUFIsU0FBU0Esa0JBQWtCO0FBQzNCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxZQUFZQyxxQkFBcUI7QUFFbkMsZ0JBQVNDLE1BQU07QUFBQSxFQUFFQztBQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUMvQixRQUFNLENBQUNDLFFBQVEsSUFBSVAsV0FBV0MsZUFBZTtBQUM3QyxTQUNJLG1DQUNLTTtBQUFBQSxpQkFBYUwsV0FBV00sTUFBTUgsUUFBUUksV0FBV0osUUFBUUs7QUFBQUEsSUFDekRQLGNBQWNJLFFBQVE7QUFBQSxPQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFUjtBQUFDRCxHQVJlRixPQUFLO0FBQUFPLEtBQUxQO0FBQUssSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNvbnRleHQiLCJDdXJyZW5jeUNvbnRleHQiLCJDVVJSRU5DSUVTIiwiQ1VSUkVOQ1lfU0lHTiIsIlByaWNlIiwicHJvZHVjdCIsIl9zIiwiY3VycmVuY3kiLCJQTE4iLCJwcmljZVBMTiIsInByaWNlVVNEIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcmljZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ3VycmVuY3lDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0N1cnJlbmN5Q29udGV4dFwiO1xuaW1wb3J0IHsgQ1VSUkVOQ0lFUywgQ1VSUkVOQ1lfU0lHTiB9IGZyb20gXCIuLi8uLi9jb25zdGFudHMvY3VycmVuY2llc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gUHJpY2UoeyBwcm9kdWN0IH0pIHtcbiAgICBjb25zdCBbY3VycmVuY3ldID0gdXNlQ29udGV4dChDdXJyZW5jeUNvbnRleHQpO1xuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICB7Y3VycmVuY3kgPT09IENVUlJFTkNJRVMuUExOID8gcHJvZHVjdC5wcmljZVBMTiA6IHByb2R1Y3QucHJpY2VVU0R9XG4gICAgICAgICAgICB7Q1VSUkVOQ1lfU0lHTltjdXJyZW5jeV19XG4gICAgICAgIDwvPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvUHJpY2UvUHJpY2UuanN4In0=