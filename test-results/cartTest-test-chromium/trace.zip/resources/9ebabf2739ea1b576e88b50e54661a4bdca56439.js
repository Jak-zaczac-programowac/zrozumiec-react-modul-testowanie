import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer/Footer.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Footer/Footer.module.css"
const __vite__css = "._footer_ix845_1 {\n    width: 100%;\n    height: 200px;\n\n    background-color: var(--color-text-default);\n    color: var(--color-white);\n\n    display: flex;\n    justify-content: center;\n    align-items: center;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const footer = "_footer_ix845_1";
export default {
	footer: footer
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))