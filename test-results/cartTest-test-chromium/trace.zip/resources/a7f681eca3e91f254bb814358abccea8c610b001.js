import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/MainPage/MainPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/MainPage/MainPage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Hero } from "/src/components/Hero/Hero.jsx";
import { Products } from "/src/components/Products/Products.jsx";
import { useLoaderData } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
export function MainPage() {
  _s();
  const {
    bestsellers,
    heroImageUrl
  } = useLoaderData();
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Hero, { heroImage: heroImageUrl }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/MainPage/MainPage.jsx",
      lineNumber: 12,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Products, { headerText: "Sprawdź nasze bestsellery", products: bestsellers }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/MainPage/MainPage.jsx",
      lineNumber: 13,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/MainPage/MainPage.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(MainPage, "hSEZntu9CtI+9VGJ2ULk6slKhhw=", false, function() {
  return [useLoaderData];
});
_c = MainPage;
var _c;
$RefreshReg$(_c, "MainPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/MainPage/MainPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVEsbUJBQ0ksY0FESjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSUixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxxQkFBcUI7QUFFdkIsZ0JBQVNDLFdBQVc7QUFBQUMsS0FBQTtBQUN2QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBYUM7QUFBQUEsRUFBYSxJQUFJSixjQUFjO0FBRXBELFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxRQUFLLFdBQVdJLGdCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCO0FBQUEsSUFDOUIsdUJBQUMsWUFDRyxZQUFXLDZCQUNYLFVBQVVELGVBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUUwQjtBQUFBLE9BSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVSO0FBQUNELEdBWmVELFVBQVE7QUFBQSxVQUNrQkQsYUFBYTtBQUFBO0FBQUFLLEtBRHZDSjtBQUFRLElBQUFJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJIZXJvIiwiUHJvZHVjdHMiLCJ1c2VMb2FkZXJEYXRhIiwiTWFpblBhZ2UiLCJfcyIsImJlc3RzZWxsZXJzIiwiaGVyb0ltYWdlVXJsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNYWluUGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSGVybyB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0hlcm8vSGVyb1wiO1xuaW1wb3J0IHsgUHJvZHVjdHMgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9Qcm9kdWN0cy9Qcm9kdWN0c1wiO1xuaW1wb3J0IHsgdXNlTG9hZGVyRGF0YSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBNYWluUGFnZSgpIHtcbiAgICBjb25zdCB7IGJlc3RzZWxsZXJzLCBoZXJvSW1hZ2VVcmwgfSA9IHVzZUxvYWRlckRhdGEoKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8SGVybyBoZXJvSW1hZ2U9e2hlcm9JbWFnZVVybH0gLz5cbiAgICAgICAgICAgIDxQcm9kdWN0c1xuICAgICAgICAgICAgICAgIGhlYWRlclRleHQ9XCJTcHJhd2TFuiBuYXN6ZSBiZXN0c2VsbGVyeVwiXG4gICAgICAgICAgICAgICAgcHJvZHVjdHM9e2Jlc3RzZWxsZXJzfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgPC8+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3JlYWN0LWNvdXJzZS96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvdmlld3MvTWFpblBhZ2UvTWFpblBhZ2UuanN4In0=