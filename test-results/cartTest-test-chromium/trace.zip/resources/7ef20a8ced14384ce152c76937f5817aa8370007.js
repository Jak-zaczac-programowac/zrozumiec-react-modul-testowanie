import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ExpandableMenu/ExpandableMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/ExpandableMenu/ExpandableMenu.module.css";
import { CATEGORIES } from "/src/constants/categories.js";
import { NavLink, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
import ARROW_ICON from "/src/assets/arrow.svg?import";
const PATH_TO_GENDER_NAME = {
  kobieta: "Kobieta",
  mezczyzna: "Mężczyzna",
  dziecko: "Dziecko"
};
export function ExpandableMenu() {
  _s();
  const params = useParams();
  const activePath = params.category;
  return /* @__PURE__ */ jsxDEV("div", { className: styles.expandableMenu, children: [
    /* @__PURE__ */ jsxDEV("p", { children: PATH_TO_GENDER_NAME[params.gender] }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
      lineNumber: 16,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: CATEGORIES.map((category) => {
      return /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV(NavLink, { to: `/${params.gender}/${category.path}`, children: [
          category.categoryName,
          " ",
          /* @__PURE__ */ jsxDEV("img", { src: ARROW_ICON, className: activePath === category.path ? styles.expanded : "" }, void 0, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
            lineNumber: 22,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
          lineNumber: 20,
          columnNumber: 29
        }, this),
        activePath === category.path && /* @__PURE__ */ jsxDEV("ul", { children: category.subcategories.map((subcategory) => {
          return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(NavLink, { to: `/${params.gender}/${params.category}/${subcategory.path}`, children: subcategory.categoryName }, void 0, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
            lineNumber: 27,
            columnNumber: 53
          }, this) }, subcategory.path, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
            lineNumber: 26,
            columnNumber: 22
          }, this);
        }) }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
          lineNumber: 24,
          columnNumber: 62
        }, this)
      ] }, category.path, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
        lineNumber: 19,
        columnNumber: 16
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
      lineNumber: 17,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
}
_s(ExpandableMenu, "+jVsTcECDRo3yq2d7EQxlN9Ixog=", false, function() {
  return [useParams];
});
_c = ExpandableMenu;
var _c;
$RefreshReg$(_c, "ExpandableMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCWixPQUFPQSxZQUFZO0FBQ25CLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxTQUFTQyxpQkFBaUI7QUFDbkMsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLHNCQUFzQjtBQUFBLEVBQ3hCQyxTQUFTO0FBQUEsRUFDVEMsV0FBVztBQUFBLEVBQ1hDLFNBQVM7QUFDYjtBQUVPLGdCQUFTQyxpQkFBaUI7QUFBQUMsS0FBQTtBQUM3QixRQUFNQyxTQUFTUixVQUFVO0FBRXpCLFFBQU1TLGFBQWFELE9BQU9FO0FBQzFCLFNBQ0ksdUJBQUMsU0FBSSxXQUFXYixPQUFPYyxnQkFDbkI7QUFBQSwyQkFBQyxPQUFHVCw4QkFBb0JNLE9BQU9JLE1BQU0sS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLElBQ3ZDLHVCQUFDLFFBQ0lkLHFCQUFXZSxJQUFLSCxjQUFhO0FBQzFCLGFBQ0ksdUJBQUMsUUFDRztBQUFBLCtCQUFDLFdBQVEsSUFBSyxJQUFHRixPQUFPSSxNQUFPLElBQUdGLFNBQVNJLElBQUssSUFDM0NKO0FBQUFBLG1CQUFTSztBQUFBQSxVQUFjO0FBQUEsVUFDeEIsdUJBQUMsU0FDRyxLQUFLZCxZQUNMLFdBQ0lRLGVBQWVDLFNBQVNJLE9BQ2xCakIsT0FBT21CLFdBQ1AsTUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1LO0FBQUEsYUFSVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNDUCxlQUFlQyxTQUFTSSxRQUNyQix1QkFBQyxRQUNJSixtQkFBU08sY0FBY0osSUFDbkJLLGlCQUFnQjtBQUNiLGlCQUNJLHVCQUFDLFFBQ0csaUNBQUMsV0FDRyxJQUFLLElBQUdWLE9BQU9JLE1BQU8sSUFBR0osT0FBT0UsUUFBUyxJQUFHUSxZQUFZSixJQUFLLElBR3pESSxzQkFBWUgsZ0JBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUEsS0FQS0csWUFBWUosTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFFBRVIsQ0FDSixLQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQTdCQ0osU0FBU0ksTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStCQTtBQUFBLElBRVIsQ0FBQyxLQXBDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUNBO0FBQUEsT0F2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdDQTtBQUVSO0FBQUNQLEdBL0NlRCxnQkFBYztBQUFBLFVBQ1hOLFNBQVM7QUFBQTtBQUFBbUIsS0FEWmI7QUFBYyxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiQ0FURUdPUklFUyIsIk5hdkxpbmsiLCJ1c2VQYXJhbXMiLCJBUlJPV19JQ09OIiwiUEFUSF9UT19HRU5ERVJfTkFNRSIsImtvYmlldGEiLCJtZXpjenl6bmEiLCJkemllY2tvIiwiRXhwYW5kYWJsZU1lbnUiLCJfcyIsInBhcmFtcyIsImFjdGl2ZVBhdGgiLCJjYXRlZ29yeSIsImV4cGFuZGFibGVNZW51IiwiZ2VuZGVyIiwibWFwIiwicGF0aCIsImNhdGVnb3J5TmFtZSIsImV4cGFuZGVkIiwic3ViY2F0ZWdvcmllcyIsInN1YmNhdGVnb3J5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJFeHBhbmRhYmxlTWVudS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9FeHBhbmRhYmxlTWVudS5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgeyBDQVRFR09SSUVTIH0gZnJvbSBcIi4uLy4uL2NvbnN0YW50cy9jYXRlZ29yaWVzXCI7XG5pbXBvcnQgeyBOYXZMaW5rLCB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IEFSUk9XX0lDT04gZnJvbSBcIi4uLy4uL2Fzc2V0cy9hcnJvdy5zdmdcIjtcblxuY29uc3QgUEFUSF9UT19HRU5ERVJfTkFNRSA9IHtcbiAgICBrb2JpZXRhOiBcIktvYmlldGFcIixcbiAgICBtZXpjenl6bmE6IFwiTcSZxbxjenl6bmFcIixcbiAgICBkemllY2tvOiBcIkR6aWVja29cIixcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBFeHBhbmRhYmxlTWVudSgpIHtcbiAgICBjb25zdCBwYXJhbXMgPSB1c2VQYXJhbXMoKTtcblxuICAgIGNvbnN0IGFjdGl2ZVBhdGggPSBwYXJhbXMuY2F0ZWdvcnk7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5leHBhbmRhYmxlTWVudX0+XG4gICAgICAgICAgICA8cD57UEFUSF9UT19HRU5ERVJfTkFNRVtwYXJhbXMuZ2VuZGVyXX08L3A+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAge0NBVEVHT1JJRVMubWFwKChjYXRlZ29yeSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17Y2F0ZWdvcnkucGF0aH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmsgdG89e2AvJHtwYXJhbXMuZ2VuZGVyfS8ke2NhdGVnb3J5LnBhdGh9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5jYXRlZ29yeU5hbWV9e1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e0FSUk9XX0lDT059XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVBhdGggPT09IGNhdGVnb3J5LnBhdGhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzdHlsZXMuZXhwYW5kZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVQYXRoID09PSBjYXRlZ29yeS5wYXRoICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnN1YmNhdGVnb3JpZXMubWFwKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdWJjYXRlZ29yeSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17c3ViY2F0ZWdvcnkucGF0aH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvJHtwYXJhbXMuZ2VuZGVyfS8ke3BhcmFtcy5jYXRlZ29yeX0vJHtzdWJjYXRlZ29yeS5wYXRofWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJjYXRlZ29yeS5jYXRlZ29yeU5hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvRXhwYW5kYWJsZU1lbnUvRXhwYW5kYWJsZU1lbnUuanN4In0=