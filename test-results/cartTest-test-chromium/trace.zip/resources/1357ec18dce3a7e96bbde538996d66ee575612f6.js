import { BACK_END_URL } from "/src/constants/api.js";

export function favouritesLoader() {
    return fetch(`${BACK_END_URL}/favourites?_expand=product`);
}
