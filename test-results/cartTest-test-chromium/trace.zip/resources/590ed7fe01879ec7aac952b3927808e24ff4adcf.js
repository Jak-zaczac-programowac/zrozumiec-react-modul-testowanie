import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ProductsList/ProductsList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { FlexContainer } from "/src/components/FlexContainer/FlexContainer.jsx";
import { ExpandableMenu } from "/src/components/ExpandableMenu/ExpandableMenu.jsx";
import { Breadcrumbs } from "/src/components/Breadcrumbs/Breadcrumbs.jsx";
import { Products } from "/src/components/Products/Products.jsx";
import { Pagination } from "/src/components/Pagination/Pagination.jsx";
import { useLoaderData, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
import { CATEGORIES } from "/src/constants/categories.js";
export function ProductsList() {
  _s();
  const {
    products,
    numberOfPages
  } = useLoaderData();
  const params = useParams();
  const foundCategory = CATEGORIES.find((c) => c.path === params.category);
  let foundSubcategory;
  if (params.subcategory) {
    foundSubcategory = foundCategory.subcategories.find((sc) => sc.path === params.subcategory);
  }
  return /* @__PURE__ */ jsxDEV(FlexContainer, { children: [
    /* @__PURE__ */ jsxDEV(ExpandableMenu, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx",
      lineNumber: 22,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(Breadcrumbs, {}, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx",
        lineNumber: 24,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Products, { headerText: foundSubcategory ? foundSubcategory.categoryName : foundCategory.categoryName, products }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx",
        lineNumber: 25,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Pagination, { numberOfPages }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx",
        lineNumber: 26,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx",
      lineNumber: 23,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_s(ProductsList, "hqo9LCNuNiFgup4B1egjbTO0cbw=", false, function() {
  return [useLoaderData, useParams];
});
_c = ProductsList;
var _c;
$RefreshReg$(_c, "ProductsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductsList/ProductsList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCWixTQUFTQSxxQkFBcUI7QUFDOUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGVBQWVDLGlCQUFpQjtBQUN6QyxTQUFTQyxrQkFBa0I7QUFDcEIsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBVUM7QUFBQUEsRUFBYyxJQUFJTixjQUFjO0FBRWxELFFBQU1PLFNBQVNOLFVBQVU7QUFFekIsUUFBTU8sZ0JBQWdCTixXQUFXTyxLQUFNQyxPQUFNQSxFQUFFQyxTQUFTSixPQUFPSyxRQUFRO0FBRXZFLE1BQUlDO0FBRUosTUFBSU4sT0FBT08sYUFBYTtBQUNwQkQsdUJBQW1CTCxjQUFjTyxjQUFjTixLQUMxQ08sUUFBT0EsR0FBR0wsU0FBU0osT0FBT08sV0FDL0I7QUFBQSxFQUNKO0FBRUEsU0FDSSx1QkFBQyxpQkFDRztBQUFBLDJCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZTtBQUFBLElBQ2YsdUJBQUMsU0FDRztBQUFBLDZCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLE1BQ1osdUJBQUMsWUFDRyxZQUNJRCxtQkFDTUEsaUJBQWlCSSxlQUNqQlQsY0FBY1MsY0FFeEIsWUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTXVCO0FBQUEsTUFFdkIsdUJBQUMsY0FBVyxpQkFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FWN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBY0E7QUFFUjtBQUFDYixHQWhDZUQsY0FBWTtBQUFBLFVBQ1lILGVBRXJCQyxTQUFTO0FBQUE7QUFBQWlCLEtBSFpmO0FBQVksSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkZsZXhDb250YWluZXIiLCJFeHBhbmRhYmxlTWVudSIsIkJyZWFkY3J1bWJzIiwiUHJvZHVjdHMiLCJQYWdpbmF0aW9uIiwidXNlTG9hZGVyRGF0YSIsInVzZVBhcmFtcyIsIkNBVEVHT1JJRVMiLCJQcm9kdWN0c0xpc3QiLCJfcyIsInByb2R1Y3RzIiwibnVtYmVyT2ZQYWdlcyIsInBhcmFtcyIsImZvdW5kQ2F0ZWdvcnkiLCJmaW5kIiwiYyIsInBhdGgiLCJjYXRlZ29yeSIsImZvdW5kU3ViY2F0ZWdvcnkiLCJzdWJjYXRlZ29yeSIsInN1YmNhdGVnb3JpZXMiLCJzYyIsImNhdGVnb3J5TmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvZHVjdHNMaXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGbGV4Q29udGFpbmVyIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvRmxleENvbnRhaW5lci9GbGV4Q29udGFpbmVyXCI7XG5pbXBvcnQgeyBFeHBhbmRhYmxlTWVudSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0V4cGFuZGFibGVNZW51L0V4cGFuZGFibGVNZW51XCI7XG5pbXBvcnQgeyBCcmVhZGNydW1icyB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0JyZWFkY3J1bWJzL0JyZWFkY3J1bWJzXCI7XG5pbXBvcnQgeyBQcm9kdWN0cyB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1Byb2R1Y3RzL1Byb2R1Y3RzXCI7XG5pbXBvcnQgeyBQYWdpbmF0aW9uIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUGFnaW5hdGlvbi9QYWdpbmF0aW9uXCI7XG5pbXBvcnQgeyB1c2VMb2FkZXJEYXRhLCB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQ0FURUdPUklFUyB9IGZyb20gXCIuLi8uLi9jb25zdGFudHMvY2F0ZWdvcmllc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RzTGlzdCgpIHtcbiAgICBjb25zdCB7IHByb2R1Y3RzLCBudW1iZXJPZlBhZ2VzIH0gPSB1c2VMb2FkZXJEYXRhKCk7XG5cbiAgICBjb25zdCBwYXJhbXMgPSB1c2VQYXJhbXMoKTtcblxuICAgIGNvbnN0IGZvdW5kQ2F0ZWdvcnkgPSBDQVRFR09SSUVTLmZpbmQoKGMpID0+IGMucGF0aCA9PT0gcGFyYW1zLmNhdGVnb3J5KTtcblxuICAgIGxldCBmb3VuZFN1YmNhdGVnb3J5O1xuXG4gICAgaWYgKHBhcmFtcy5zdWJjYXRlZ29yeSkge1xuICAgICAgICBmb3VuZFN1YmNhdGVnb3J5ID0gZm91bmRDYXRlZ29yeS5zdWJjYXRlZ29yaWVzLmZpbmQoXG4gICAgICAgICAgICAoc2MpID0+IHNjLnBhdGggPT09IHBhcmFtcy5zdWJjYXRlZ29yeVxuICAgICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxGbGV4Q29udGFpbmVyPlxuICAgICAgICAgICAgPEV4cGFuZGFibGVNZW51IC8+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxCcmVhZGNydW1icyAvPlxuICAgICAgICAgICAgICAgIDxQcm9kdWN0c1xuICAgICAgICAgICAgICAgICAgICBoZWFkZXJUZXh0PXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvdW5kU3ViY2F0ZWdvcnlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGZvdW5kU3ViY2F0ZWdvcnkuY2F0ZWdvcnlOYW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3VuZENhdGVnb3J5LmNhdGVnb3J5TmFtZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3RzPXtwcm9kdWN0c31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxQYWdpbmF0aW9uIG51bWJlck9mUGFnZXM9e251bWJlck9mUGFnZXN9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9GbGV4Q29udGFpbmVyPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL3ZpZXdzL1Byb2R1Y3RzTGlzdC9Qcm9kdWN0c0xpc3QuanN4In0=