import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Hero/Hero.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import style from "/src/components/Hero/Hero.module.css";
import { CenteredContent } from "/src/components/CenteredContent/CenteredContent.jsx";
import { FullWidthButton } from "/src/components/FullWidthButton/FullWidthButton.jsx";
export function Hero({
  heroImage
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: style.hero, style: {
    backgroundImage: `url(${heroImage})`
  }, children: /* @__PURE__ */ jsxDEV(CenteredContent, { children: /* @__PURE__ */ jsxDEV("div", { className: style.contentWrapper, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Letnie promocje do -70%!" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx",
      lineNumber: 12,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "Tylko najlepsze okazje!" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx",
      lineNumber: 13,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(FullWidthButton, { children: "Sprawdź produkty" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx",
      lineNumber: 14,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx",
    lineNumber: 11,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx",
    lineNumber: 10,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = Hero;
var _c;
$RefreshReg$(_c, "Hero");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWW9CO0FBWnBCLE9BQU9BLG9CQUFXO0FBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNyQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsdUJBQXVCO0FBRXpCLGdCQUFTQyxLQUFLO0FBQUEsRUFBRUM7QUFBVSxHQUFHO0FBQ2hDLFNBQ0ksdUJBQUMsU0FDRyxXQUFXSixNQUFNSyxNQUNqQixPQUFPO0FBQUEsSUFBRUMsaUJBQWtCLE9BQU1GLFNBQVU7QUFBQSxFQUFHLEdBRTlDLGlDQUFDLG1CQUNHLGlDQUFDLFNBQUksV0FBV0osTUFBTU8sZ0JBQ2xCO0FBQUEsMkJBQUMsUUFBRyx3Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsSUFDNUIsdUJBQUMsT0FBRSx1Q0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsSUFDMUIsdUJBQUMsbUJBQWdCLGdDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsT0FIckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRVI7QUFBQ0MsS0FmZUw7QUFBSSxJQUFBSztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGUiLCJDZW50ZXJlZENvbnRlbnQiLCJGdWxsV2lkdGhCdXR0b24iLCJIZXJvIiwiaGVyb0ltYWdlIiwiaGVybyIsImJhY2tncm91bmRJbWFnZSIsImNvbnRlbnRXcmFwcGVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJIZXJvLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGUgZnJvbSBcIi4vSGVyby5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgeyBDZW50ZXJlZENvbnRlbnQgfSBmcm9tIFwiLi4vQ2VudGVyZWRDb250ZW50L0NlbnRlcmVkQ29udGVudFwiO1xuaW1wb3J0IHsgRnVsbFdpZHRoQnV0dG9uIH0gZnJvbSBcIi4uL0Z1bGxXaWR0aEJ1dHRvbi9GdWxsV2lkdGhCdXR0b25cIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEhlcm8oeyBoZXJvSW1hZ2UgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGUuaGVyb31cbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRJbWFnZTogYHVybCgke2hlcm9JbWFnZX0pYCB9fVxuICAgICAgICA+XG4gICAgICAgICAgICA8Q2VudGVyZWRDb250ZW50PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZS5jb250ZW50V3JhcHBlcn0+XG4gICAgICAgICAgICAgICAgICAgIDxoMj5MZXRuaWUgcHJvbW9jamUgZG8gLTcwJSE8L2gyPlxuICAgICAgICAgICAgICAgICAgICA8cD5UeWxrbyBuYWpsZXBzemUgb2themplITwvcD5cbiAgICAgICAgICAgICAgICAgICAgPEZ1bGxXaWR0aEJ1dHRvbj5TcHJhd2TFuiBwcm9kdWt0eTwvRnVsbFdpZHRoQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9DZW50ZXJlZENvbnRlbnQ+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvSGVyby9IZXJvLmpzeCJ9