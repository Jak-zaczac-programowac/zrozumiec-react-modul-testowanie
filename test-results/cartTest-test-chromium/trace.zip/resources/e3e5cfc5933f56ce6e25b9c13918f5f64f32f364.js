import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Photos/Photos.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/Photos/Photos.module.css";
import { FlexContainer } from "/src/components/FlexContainer/FlexContainer.jsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useState = __vite__cjsImport5_react["useState"];
export function Photos({
  product
}) {
  _s();
  const [currentPhoto, setCurrentPhoto] = useState(product.photos[0]);
  return /* @__PURE__ */ jsxDEV(FlexContainer, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: styles.thumbnails, children: product.photos.map((photo) => {
      return /* @__PURE__ */ jsxDEV("img", { className: currentPhoto === photo ? styles.active : "", onClick: () => {
        setCurrentPhoto(photo);
      }, src: photo }, photo, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.jsx",
        lineNumber: 13,
        columnNumber: 16
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.jsx",
      lineNumber: 11,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("img", { className: styles.mainPhoto, src: currentPhoto }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.jsx",
      lineNumber: 18,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(Photos, "XWBmyP/c+jpn6qxuOH+9r7nbtTk=");
_c = Photos;
var _c;
$RefreshReg$(_c, "Photos");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVp4QixPQUFPQSxZQUFZO0FBQ25CLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFFbEIsZ0JBQVNDLE9BQU87QUFBQSxFQUFFQztBQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUNoQyxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSUwsU0FBU0UsUUFBUUksT0FBTyxDQUFDLENBQUM7QUFFbEUsU0FDSSx1QkFBQyxpQkFDRztBQUFBLDJCQUFDLFNBQUksV0FBV1IsT0FBT1MsWUFDbEJMLGtCQUFRSSxPQUFPRSxJQUFLQyxXQUFVO0FBQzNCLGFBQ0ksdUJBQUMsU0FDRyxXQUNJTCxpQkFBaUJLLFFBQVFYLE9BQU9ZLFNBQVMsSUFFN0MsU0FBUyxNQUFNO0FBQ1hMLHdCQUFnQkksS0FBSztBQUFBLE1BQ3pCLEdBRUEsS0FBS0EsU0FEQUEsT0FQVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUWU7QUFBQSxJQUd2QixDQUFDLEtBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdYLE9BQU9hLFdBQVcsS0FBS1AsZ0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0Q7QUFBQSxPQWpCeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVSO0FBQUNELEdBeEJlRixRQUFNO0FBQUFXLEtBQU5YO0FBQU0sSUFBQVc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlcyIsIkZsZXhDb250YWluZXIiLCJ1c2VTdGF0ZSIsIlBob3RvcyIsInByb2R1Y3QiLCJfcyIsImN1cnJlbnRQaG90byIsInNldEN1cnJlbnRQaG90byIsInBob3RvcyIsInRodW1ibmFpbHMiLCJtYXAiLCJwaG90byIsImFjdGl2ZSIsIm1haW5QaG90byIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGhvdG9zLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL1Bob3Rvcy5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgeyBGbGV4Q29udGFpbmVyIH0gZnJvbSBcIi4uL0ZsZXhDb250YWluZXIvRmxleENvbnRhaW5lclwiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFBob3Rvcyh7IHByb2R1Y3QgfSkge1xuICAgIGNvbnN0IFtjdXJyZW50UGhvdG8sIHNldEN1cnJlbnRQaG90b10gPSB1c2VTdGF0ZShwcm9kdWN0LnBob3Rvc1swXSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8RmxleENvbnRhaW5lcj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudGh1bWJuYWlsc30+XG4gICAgICAgICAgICAgICAge3Byb2R1Y3QucGhvdG9zLm1hcCgocGhvdG8pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50UGhvdG8gPT09IHBob3RvID8gc3R5bGVzLmFjdGl2ZSA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50UGhvdG8ocGhvdG8pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwaG90b31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e3Bob3RvfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9e3N0eWxlcy5tYWluUGhvdG99IHNyYz17Y3VycmVudFBob3RvfSAvPlxuICAgICAgICA8L0ZsZXhDb250YWluZXI+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3JlYWN0LWNvdXJzZS96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9QaG90b3MvUGhvdG9zLmpzeCJ9