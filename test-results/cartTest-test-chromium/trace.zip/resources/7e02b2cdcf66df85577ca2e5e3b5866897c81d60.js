import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CartSummary/CartSummary.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.module.css"
const __vite__css = "._cartSummary_190qz_1 {\n    display: flex;\n    flex-direction: column;\n    padding-right: 1rem;\n    margin-top: 1rem;\n    gap: 1rem;\n    width: 28rem;\n}\n\n._cartSummary_190qz_1 h2 {\n    border-bottom: 1px solid var(--color-text-grey);\n    padding-bottom: 1rem;\n}\n\n._cartRow_190qz_15 {\n    display: flex;\n    justify-content: space-between;\n}\n\n._cartSummaryRow_190qz_20 {\n    font-weight: 700;\n}\n\n._deliveryInfo_190qz_24 {\n    display: flex;\n    justify-content: space-between;\n    padding: 1rem;\n    font-weight: 700;\n    background-color: var(--color-grey);\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const cartSummary = "_cartSummary_190qz_1";
export const cartRow = "_cartRow_190qz_15";
export const cartSummaryRow = "_cartSummaryRow_190qz_20";
export const deliveryInfo = "_deliveryInfo_190qz_24";
export default {
	cartSummary: cartSummary,
	cartRow: cartRow,
	cartSummaryRow: cartSummaryRow,
	deliveryInfo: deliveryInfo
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))