import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MainContent/MainContent.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainContent/MainContent.module.css"
const __vite__css = "._mainContent_1ifjb_1 {\n    width: 100%;\n    flex: 1;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const mainContent = "_mainContent_1ifjb_1";
export default {
	mainContent: mainContent
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))