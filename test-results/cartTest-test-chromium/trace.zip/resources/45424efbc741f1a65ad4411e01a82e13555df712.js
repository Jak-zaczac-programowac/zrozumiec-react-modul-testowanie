import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ProductDetails/ProductDetails.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { FlexContainer } from "/src/components/FlexContainer/FlexContainer.jsx";
import { ExpandableMenu } from "/src/components/ExpandableMenu/ExpandableMenu.jsx";
import { Breadcrumbs } from "/src/components/Breadcrumbs/Breadcrumbs.jsx";
import { Photos } from "/src/components/Photos/Photos.jsx";
import { Details } from "/src/components/Details/Details.jsx";
import { useLoaderData } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
export function ProductDetails() {
  _s();
  const product = useLoaderData();
  return /* @__PURE__ */ jsxDEV(FlexContainer, { children: [
    /* @__PURE__ */ jsxDEV(ExpandableMenu, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
      lineNumber: 12,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      width: "100%"
    }, children: [
      /* @__PURE__ */ jsxDEV(Breadcrumbs, {}, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
        lineNumber: 16,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(FlexContainer, { children: [
        /* @__PURE__ */ jsxDEV(Photos, { product }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
          lineNumber: 18,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Details, { product }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
          lineNumber: 19,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
        lineNumber: 17,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
      lineNumber: 13,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(ProductDetails, "Uv2KgiCFDP+f2kNMFGGhKUhmTCk=", false, function() {
  return [useLoaderData];
});
_c = ProductDetails;
var _c;
$RefreshReg$(_c, "ProductDetails");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/ProductDetails/ProductDetails.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWlosU0FBU0EscUJBQXFCO0FBQzlCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHFCQUFxQjtBQUV2QixnQkFBU0MsaUJBQWlCO0FBQUFDLEtBQUE7QUFDN0IsUUFBTUMsVUFBVUgsY0FBYztBQUU5QixTQUNJLHVCQUFDLGlCQUNHO0FBQUEsMkJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFDZix1QkFBQyxTQUFJLE9BQU87QUFBQSxNQUFFSSxPQUFPO0FBQUEsSUFBTyxHQUN4QjtBQUFBLDZCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLE1BQ1osdUJBQUMsaUJBQ0c7QUFBQSwrQkFBQyxVQUFPLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFdBQVEsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUEsV0FGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVSO0FBQUNGLEdBZmVELGdCQUFjO0FBQUEsVUFDVkQsYUFBYTtBQUFBO0FBQUFLLEtBRGpCSjtBQUFjLElBQUFJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJGbGV4Q29udGFpbmVyIiwiRXhwYW5kYWJsZU1lbnUiLCJCcmVhZGNydW1icyIsIlBob3RvcyIsIkRldGFpbHMiLCJ1c2VMb2FkZXJEYXRhIiwiUHJvZHVjdERldGFpbHMiLCJfcyIsInByb2R1Y3QiLCJ3aWR0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvZHVjdERldGFpbHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZsZXhDb250YWluZXIgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9GbGV4Q29udGFpbmVyL0ZsZXhDb250YWluZXJcIjtcbmltcG9ydCB7IEV4cGFuZGFibGVNZW51IH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvRXhwYW5kYWJsZU1lbnUvRXhwYW5kYWJsZU1lbnVcIjtcbmltcG9ydCB7IEJyZWFkY3J1bWJzIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvQnJlYWRjcnVtYnMvQnJlYWRjcnVtYnNcIjtcbmltcG9ydCB7IFBob3RvcyB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1Bob3Rvcy9QaG90b3NcIjtcbmltcG9ydCB7IERldGFpbHMgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9EZXRhaWxzL0RldGFpbHNcIjtcbmltcG9ydCB7IHVzZUxvYWRlckRhdGEgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdERldGFpbHMoKSB7XG4gICAgY29uc3QgcHJvZHVjdCA9IHVzZUxvYWRlckRhdGEoKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxGbGV4Q29udGFpbmVyPlxuICAgICAgICAgICAgPEV4cGFuZGFibGVNZW51IC8+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cbiAgICAgICAgICAgICAgICA8QnJlYWRjcnVtYnMgLz5cbiAgICAgICAgICAgICAgICA8RmxleENvbnRhaW5lcj5cbiAgICAgICAgICAgICAgICAgICAgPFBob3RvcyBwcm9kdWN0PXtwcm9kdWN0fSAvPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlscyBwcm9kdWN0PXtwcm9kdWN0fSAvPlxuICAgICAgICAgICAgICAgIDwvRmxleENvbnRhaW5lcj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0ZsZXhDb250YWluZXI+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3JlYWN0LWNvdXJzZS96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvdmlld3MvUHJvZHVjdERldGFpbHMvUHJvZHVjdERldGFpbHMuanN4In0=