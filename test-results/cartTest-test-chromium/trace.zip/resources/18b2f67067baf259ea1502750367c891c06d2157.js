import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useState = __vite__cjsImport0_react["useState"];

export function useLocalStorage(key, defaultValue) {
    function getJSONFromLocalStorage() {
        if (localStorage[key]) {
            return JSON.parse(localStorage[key]);
        } else {
            return defaultValue;
        }
    }

    const [data, setData] = useState(() => getJSONFromLocalStorage());

    function setJSONTOLocalStorage(newData) {
        setData(newData);
        localStorage[key] = JSON.stringify(newData);
    }

    return [data, setJSONTOLocalStorage];
}
