import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Product/Product.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.module.css"
const __vite__css = "._product_a4vfx_1 {\n    position: relative;\n}\n\n._product_a4vfx_1 button {\n    border: none;\n}\n\n._product_a4vfx_1 img {\n    width: 250px;\n    height: 400px;\n}\n\n._product_a4vfx_1 h3 {\n    font-weight: 700;\n    margin: 0.5rem 0;\n}\n\n._product_a4vfx_1 p {\n    color: var(--color-price);\n    margin-bottom: 1rem;\n}\n\n._heart_a4vfx_24 {\n    position: absolute;\n    top: 0.5rem;\n    left: 0.5rem;\n\n    width: 1.5rem;\n    height: 1.5rem;\n\n    background-image: url(\"/src/assets/heart.svg\");\n    background-repeat: none;\n}\n\n._heart_a4vfx_24:hover {\n    background-image: url(\"/src/assets/heart-full.svg\");\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const product = "_product_a4vfx_1";
export const heart = "_heart_a4vfx_24";
export default {
	product: product,
	heart: heart
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))