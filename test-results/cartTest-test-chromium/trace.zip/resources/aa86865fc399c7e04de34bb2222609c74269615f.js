import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const createContext = __vite__cjsImport0_react["createContext"];

export const CartContext = createContext();
