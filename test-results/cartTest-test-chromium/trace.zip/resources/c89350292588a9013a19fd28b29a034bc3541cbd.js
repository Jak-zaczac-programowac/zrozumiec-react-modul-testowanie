import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Photos/Photos.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Photos/Photos.module.css"
const __vite__css = "._thumbnails_178ad_1 {\n    display: flex;\n    flex-direction: column;\n    gap: 1rem;\n}\n\n._thumbnails_178ad_1 img {\n    width: 85px;\n    height: 120px;\n    cursor: pointer;\n}\n\n._thumbnails_178ad_1 img._active_178ad_13 {\n    border: 2px solid var(--color-text-default);\n}\n\n._mainPhoto_178ad_17 {\n    width: 500px;\n    height: 700px;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const thumbnails = "_thumbnails_178ad_1";
export const active = "_active_178ad_13";
export const mainPhoto = "_mainPhoto_178ad_17";
export default {
	thumbnails: thumbnails,
	active: active,
	mainPhoto: mainPhoto
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))