import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Details/Details.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/Details/Details.module.css";
import CAR_ICON from "/src/assets/car.svg?import";
import RETURN_ICON from "/src/assets/return.svg?import";
import { FullWidthButton } from "/src/components/FullWidthButton/FullWidthButton.jsx";
import { Accordion } from "/src/components/Accordion/Accordion.jsx";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useContext = __vite__cjsImport8_react["useContext"];
import { CartContext } from "/src/contexts/CartContext.js";
export function Details({
  product
}) {
  _s();
  const [, addProductToCart] = useContext(CartContext);
  const accordionContent = [{
    title: "Opis produktu",
    content: product.description
  }, {
    title: "Wskazówki pielęgnacyjne",
    content: product.maintenanceInfo
  }];
  return /* @__PURE__ */ jsxDEV("div", { className: styles.details, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: product.brand }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
      lineNumber: 22,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: styles.productName, children: product.productName }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
      lineNumber: 23,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: styles.price, children: [
      product.pricePLN,
      "zł"
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
      lineNumber: 24,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FullWidthButton, { onClick: () => {
      addProductToCart(product);
    }, isBlack: true, children: "Dodaj do koszyka" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
      lineNumber: 26,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: styles.extraInfo, children: [
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("img", { src: CAR_ICON }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
          lineNumber: 34,
          columnNumber: 21
        }, this),
        "Dostawa do 24h"
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
        lineNumber: 33,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("img", { src: RETURN_ICON }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
          lineNumber: 38,
          columnNumber: 21
        }, this),
        "Zwrot do 100 dni!"
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
        lineNumber: 37,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
      lineNumber: 32,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Accordion, { items: accordionContent }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
      lineNumber: 43,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_s(Details, "xZklESQi2xjHbdePBkPWS7fiuMQ=");
_c = Details;
var _c;
$RefreshReg$(_c, "Details");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCWixPQUFPQSxZQUFZO0FBRW5CLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG1CQUFtQjtBQUVyQixnQkFBU0MsUUFBUTtBQUFBLEVBQUVDO0FBQVEsR0FBRztBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sR0FBR0MsZ0JBQWdCLElBQUlMLFdBQVdDLFdBQVc7QUFFbkQsUUFBTUssbUJBQW1CLENBQ3JCO0FBQUEsSUFDSUMsT0FBTztBQUFBLElBQ1BDLFNBQVNMLFFBQVFNO0FBQUFBLEVBQ3JCLEdBQ0E7QUFBQSxJQUNJRixPQUFPO0FBQUEsSUFDUEMsU0FBU0wsUUFBUU87QUFBQUEsRUFDckIsQ0FBQztBQUdMLFNBQ0ksdUJBQUMsU0FBSSxXQUFXZixPQUFPZ0IsU0FDbkI7QUFBQSwyQkFBQyxRQUFJUixrQkFBUVMsU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CO0FBQUEsSUFDbkIsdUJBQUMsT0FBRSxXQUFXakIsT0FBT2tCLGFBQWNWLGtCQUFRVSxlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFDdkQsdUJBQUMsT0FBRSxXQUFXbEIsT0FBT21CLE9BQVFYO0FBQUFBLGNBQVFZO0FBQUFBLE1BQVM7QUFBQSxTQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdEO0FBQUEsSUFFaEQsdUJBQUMsbUJBQ0csU0FBUyxNQUFNO0FBQ1hWLHVCQUFpQkYsT0FBTztBQUFBLElBQzVCLEdBQ0EsU0FBUyxNQUFLLGdDQUpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFFBQUcsV0FBV1IsT0FBT3FCLFdBQ2xCO0FBQUEsNkJBQUMsUUFDRztBQUFBLCtCQUFDLFNBQUksS0FBS3BCLFlBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBO0FBQUEsV0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxRQUNHO0FBQUEsK0JBQUMsU0FBSSxLQUFLQyxlQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0I7QUFBQTtBQUFBLFdBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxhQUFVLE9BQU9TLG9CQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1DO0FBQUEsT0F6QnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFUjtBQUFDRixHQTNDZUYsU0FBTztBQUFBZSxLQUFQZjtBQUFPLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJzdHlsZXMiLCJDQVJfSUNPTiIsIlJFVFVSTl9JQ09OIiwiRnVsbFdpZHRoQnV0dG9uIiwiQWNjb3JkaW9uIiwidXNlQ29udGV4dCIsIkNhcnRDb250ZXh0IiwiRGV0YWlscyIsInByb2R1Y3QiLCJfcyIsImFkZFByb2R1Y3RUb0NhcnQiLCJhY2NvcmRpb25Db250ZW50IiwidGl0bGUiLCJjb250ZW50IiwiZGVzY3JpcHRpb24iLCJtYWludGVuYW5jZUluZm8iLCJkZXRhaWxzIiwiYnJhbmQiLCJwcm9kdWN0TmFtZSIsInByaWNlIiwicHJpY2VQTE4iLCJleHRyYUluZm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRldGFpbHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vRGV0YWlscy5tb2R1bGUuY3NzXCI7XG5cbmltcG9ydCBDQVJfSUNPTiBmcm9tIFwiLi4vLi4vYXNzZXRzL2Nhci5zdmdcIjtcbmltcG9ydCBSRVRVUk5fSUNPTiBmcm9tIFwiLi4vLi4vYXNzZXRzL3JldHVybi5zdmdcIjtcbmltcG9ydCB7IEZ1bGxXaWR0aEJ1dHRvbiB9IGZyb20gXCIuLi9GdWxsV2lkdGhCdXR0b24vRnVsbFdpZHRoQnV0dG9uXCI7XG5pbXBvcnQgeyBBY2NvcmRpb24gfSBmcm9tIFwiLi4vQWNjb3JkaW9uL0FjY29yZGlvblwiO1xuaW1wb3J0IHsgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ2FydENvbnRleHQgfSBmcm9tIFwiLi4vLi4vY29udGV4dHMvQ2FydENvbnRleHRcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIERldGFpbHMoeyBwcm9kdWN0IH0pIHtcbiAgICBjb25zdCBbLCBhZGRQcm9kdWN0VG9DYXJ0XSA9IHVzZUNvbnRleHQoQ2FydENvbnRleHQpO1xuXG4gICAgY29uc3QgYWNjb3JkaW9uQ29udGVudCA9IFtcbiAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6IFwiT3BpcyBwcm9kdWt0dVwiLFxuICAgICAgICAgICAgY29udGVudDogcHJvZHVjdC5kZXNjcmlwdGlvbixcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6IFwiV3NrYXrDs3draSBwaWVsxJlnbmFjeWpuZVwiLFxuICAgICAgICAgICAgY29udGVudDogcHJvZHVjdC5tYWludGVuYW5jZUluZm8sXG4gICAgICAgIH0sXG4gICAgXTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZGV0YWlsc30+XG4gICAgICAgICAgICA8aDI+e3Byb2R1Y3QuYnJhbmR9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17c3R5bGVzLnByb2R1Y3ROYW1lfT57cHJvZHVjdC5wcm9kdWN0TmFtZX08L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5wcmljZX0+e3Byb2R1Y3QucHJpY2VQTE59esWCPC9wPlxuXG4gICAgICAgICAgICA8RnVsbFdpZHRoQnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBhZGRQcm9kdWN0VG9DYXJ0KHByb2R1Y3QpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgaXNCbGFjaz17dHJ1ZX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBEb2RhaiBkbyBrb3N6eWthXG4gICAgICAgICAgICA8L0Z1bGxXaWR0aEJ1dHRvbj5cblxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT17c3R5bGVzLmV4dHJhSW5mb30+XG4gICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17Q0FSX0lDT059IC8+XG4gICAgICAgICAgICAgICAgICAgIERvc3Rhd2EgZG8gMjRoXG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtSRVRVUk5fSUNPTn0gLz5cbiAgICAgICAgICAgICAgICAgICAgWndyb3QgZG8gMTAwIGRuaSFcbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPC91bD5cblxuICAgICAgICAgICAgPEFjY29yZGlvbiBpdGVtcz17YWNjb3JkaW9uQ29udGVudH0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3JlYWN0LWNvdXJzZS96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9EZXRhaWxzL0RldGFpbHMuanN4In0=