import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CartProduct/CartProduct.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.module.css"
const __vite__css = "._favouriteProduct_1e29n_1 {\n    padding: 1rem 0;\n    display: flex;\n    gap: 3rem;\n    border-top: 1px solid var(--color-text-grey);\n    margin: 0.5rem 0;\n}\n\n._favouriteProduct_1e29n_1 img {\n    width: 85px;\n    height: 140px;\n}\n\n._favouriteProductInfo_1e29n_14 {\n    display: flex;\n    flex: 1;\n    flex-direction: column;\n}\n\n._topRow_1e29n_20 {\n    display: flex;\n    justify-content: space-between;\n    font-size: 1.25rem;\n    margin-bottom: 1rem;\n    font-weight: 700;\n}\n\n._priceRow_1e29n_28 span {\n    color: var(--color-text-grey);\n    font-weight: normal;\n}\n\n._priceRow_1e29n_28 p {\n    font-weight: 700;\n}\n\n._buttonRow_1e29n_37 {\n    display: flex;\n    gap: 2rem;\n    flex: 1;\n    align-items: flex-end;\n}\n\n._buttonRow_1e29n_37 button {\n    border: none;\n    background: none;\n}\n\n._buttonRow_1e29n_37 button img {\n    margin-right: 0.5rem;\n    width: 1rem;\n    height: 1rem;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const favouriteProduct = "_favouriteProduct_1e29n_1";
export const favouriteProductInfo = "_favouriteProductInfo_1e29n_14";
export const topRow = "_topRow_1e29n_20";
export const priceRow = "_priceRow_1e29n_28";
export const buttonRow = "_buttonRow_1e29n_37";
export default {
	favouriteProduct: favouriteProduct,
	favouriteProductInfo: favouriteProductInfo,
	topRow: topRow,
	priceRow: priceRow,
	buttonRow: buttonRow
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))