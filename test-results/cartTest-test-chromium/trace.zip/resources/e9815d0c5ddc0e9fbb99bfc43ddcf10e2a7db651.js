import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Accordion/Accordion.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/Accordion/Accordion.module.css";
import ARROW_ICON from "/src/assets/arrow.svg?import";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useState = __vite__cjsImport5_react["useState"];
export function Accordion({
  items
}) {
  _s();
  const [activeItemIndex, setActiveItem] = useState(0);
  return /* @__PURE__ */ jsxDEV("ul", { children: items.map((item, index) => {
    return /* @__PURE__ */ jsxDEV("li", { onClick: () => {
      setActiveItem(index);
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: styles.item, children: [
        /* @__PURE__ */ jsxDEV("p", { children: item.title }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx",
          lineNumber: 16,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("img", { className: activeItemIndex === index ? styles.expanded : "", src: ARROW_ICON }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx",
          lineNumber: 17,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx",
        lineNumber: 15,
        columnNumber: 25
      }, this),
      activeItemIndex === index && /* @__PURE__ */ jsxDEV("p", { children: item.content }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx",
        lineNumber: 19,
        columnNumber: 55
      }, this)
    ] }, item.title, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx",
      lineNumber: 12,
      columnNumber: 14
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(Accordion, "r5bc94r44geW9a1dzhezXiHDiJ4=");
_c = Accordion;
var _c;
$RefreshReg$(_c, "Accordion");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Accordion/Accordion.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUI0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqQjVCLE9BQU9BLFlBQVk7QUFDbkIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUNsQixnQkFBU0MsVUFBVTtBQUFBLEVBQUVDO0FBQU0sR0FBRztBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sQ0FBQ0MsaUJBQWlCQyxhQUFhLElBQUlMLFNBQVMsQ0FBQztBQUVuRCxTQUNJLHVCQUFDLFFBQ0lFLGdCQUFNSSxJQUFJLENBQUNDLE1BQU1DLFVBQVU7QUFDeEIsV0FDSSx1QkFBQyxRQUVHLFNBQVMsTUFBTTtBQUNYSCxvQkFBY0csS0FBSztBQUFBLElBQ3ZCLEdBRUE7QUFBQSw2QkFBQyxTQUFJLFdBQVdWLE9BQU9TLE1BQ25CO0FBQUEsK0JBQUMsT0FBR0EsZUFBS0UsU0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmLHVCQUFDLFNBQ0csV0FDSUwsb0JBQW9CSSxRQUNkVixPQUFPWSxXQUNQLElBRVYsS0FBS1gsY0FOVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTW9CO0FBQUEsV0FSeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQ0ssb0JBQW9CSSxTQUFTLHVCQUFDLE9BQUdELGVBQUtJLFdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLFNBaEIxQ0osS0FBS0UsT0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsRUFFUixDQUFDLEtBdkJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFUjtBQUFDTixHQTlCZUYsV0FBUztBQUFBVyxLQUFUWDtBQUFTLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJzdHlsZXMiLCJBUlJPV19JQ09OIiwidXNlU3RhdGUiLCJBY2NvcmRpb24iLCJpdGVtcyIsIl9zIiwiYWN0aXZlSXRlbUluZGV4Iiwic2V0QWN0aXZlSXRlbSIsIm1hcCIsIml0ZW0iLCJpbmRleCIsInRpdGxlIiwiZXhwYW5kZWQiLCJjb250ZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBY2NvcmRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vQWNjb3JkaW9uLm1vZHVsZS5jc3NcIjtcbmltcG9ydCBBUlJPV19JQ09OIGZyb20gXCIuLi8uLi9hc3NldHMvYXJyb3cuc3ZnXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuZXhwb3J0IGZ1bmN0aW9uIEFjY29yZGlvbih7IGl0ZW1zIH0pIHtcbiAgICBjb25zdCBbYWN0aXZlSXRlbUluZGV4LCBzZXRBY3RpdmVJdGVtXSA9IHVzZVN0YXRlKDApO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPHVsPlxuICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8bGlcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVJdGVtKGluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuaXRlbX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+e2l0ZW0udGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUl0ZW1JbmRleCA9PT0gaW5kZXhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHN0eWxlcy5leHBhbmRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17QVJST1dfSUNPTn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlSXRlbUluZGV4ID09PSBpbmRleCAmJiA8cD57aXRlbS5jb250ZW50fTwvcD59XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICA8L3VsPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvQWNjb3JkaW9uL0FjY29yZGlvbi5qc3gifQ==