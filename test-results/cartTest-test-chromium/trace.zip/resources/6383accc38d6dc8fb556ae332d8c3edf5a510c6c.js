export const PATH_TO_ENDPOINT_MAPPING = {
    kobieta: "women",
    mezczyzna: "men",
    dziecko: "children",
};

export const BACK_END_URL = "http://localhost:3000";
