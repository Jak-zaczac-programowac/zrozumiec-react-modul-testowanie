import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FavouriteProduct/FavouriteProduct.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/FavouriteProduct/FavouriteProduct.module.css";
import REMOVE_ICON from "/src/assets/remove.svg?import";
import BAG_ICON from "/src/assets/bag.svg?import";
import { useFetcher } from "/node_modules/.vite/deps/react-router-dom.js?v=6c826b96";
import { Price } from "/src/components/Price/Price.jsx";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useContext = __vite__cjsImport8_react["useContext"];
import { CartContext } from "/src/contexts/CartContext.js";
export function FavouriteProduct({
  favourite
}) {
  _s();
  const product = favourite.product;
  const {
    Form
  } = useFetcher();
  const price = /* @__PURE__ */ jsxDEV(Price, { product }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
    lineNumber: 17,
    columnNumber: 17
  }, this);
  const [, addProductToCart] = useContext(CartContext);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.favouriteProduct, children: [
    /* @__PURE__ */ jsxDEV("img", { src: product.photos[0] }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
      lineNumber: 20,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.favouriteProductInfo, children: [
      /* @__PURE__ */ jsxDEV("div", { className: styles.topRow, children: [
        /* @__PURE__ */ jsxDEV("h3", { children: [
          product.brand,
          " ",
          product.productName
        ] }, void 0, true, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
          lineNumber: 23,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: price }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
          lineNumber: 26,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
        lineNumber: 22,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: styles.priceRow, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Cena: " }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
          lineNumber: 29,
          columnNumber: 21
        }, this),
        price
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
        lineNumber: 28,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: styles.buttonRow, children: [
        /* @__PURE__ */ jsxDEV(Form, { action: `/delete-from-favourites/${favourite.id}`, method: "DELETE", children: /* @__PURE__ */ jsxDEV("button", { children: [
          /* @__PURE__ */ jsxDEV("img", { src: REMOVE_ICON }, void 0, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
            lineNumber: 35,
            columnNumber: 29
          }, this),
          "Usuń"
        ] }, void 0, true, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
          lineNumber: 34,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
          lineNumber: 33,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => {
          addProductToCart(product);
        }, children: [
          /* @__PURE__ */ jsxDEV("img", { src: BAG_ICON }, void 0, false, {
            fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
            lineNumber: 42,
            columnNumber: 25
          }, this),
          "Dodaj do koszyka"
        ] }, void 0, true, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
          lineNumber: 39,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
        lineNumber: 32,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
      lineNumber: 21,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
}
_s(FavouriteProduct, "jF48S9cikn2WTtQA8f9ZSXBOQTo=", false, function() {
  return [useFetcher];
});
_c = FavouriteProduct;
var _c;
$RefreshReg$(_c, "FavouriteProduct");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouriteProduct/FavouriteProduct.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWWtCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVpsQixPQUFPQSxZQUFZO0FBQ25CLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxjQUFjO0FBQ3JCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxtQkFBbUI7QUFFckIsZ0JBQVNDLGlCQUFpQjtBQUFBLEVBQUVDO0FBQVUsR0FBRztBQUFBQyxLQUFBO0FBQzVDLFFBQU1DLFVBQVVGLFVBQVVFO0FBQzFCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFLLElBQUlSLFdBQVc7QUFFNUIsUUFBTVMsUUFBUSx1QkFBQyxTQUFNLFdBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QjtBQUV0QyxRQUFNLEdBQUdDLGdCQUFnQixJQUFJUixXQUFXQyxXQUFXO0FBRW5ELFNBQ0ksdUJBQUMsU0FBSSxXQUFXTixPQUFPYyxrQkFDbkI7QUFBQSwyQkFBQyxTQUFJLEtBQUtKLFFBQVFLLE9BQU8sQ0FBQyxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsSUFDNUIsdUJBQUMsU0FBSSxXQUFXZixPQUFPZ0Isc0JBQ25CO0FBQUEsNkJBQUMsU0FBSSxXQUFXaEIsT0FBT2lCLFFBQ25CO0FBQUEsK0JBQUMsUUFDSVA7QUFBQUEsa0JBQVFRO0FBQUFBLFVBQU07QUFBQSxVQUFFUixRQUFRUztBQUFBQSxhQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUdQLG1CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVTtBQUFBLFdBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVdaLE9BQU9vQixVQUNqQjtBQUFBLCtCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFDWFI7QUFBQUEsV0FGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBV1osT0FBT3FCLFdBQ25CO0FBQUEsK0JBQUMsUUFDRyxRQUFTLDJCQUEwQmIsVUFBVWMsRUFBRyxJQUNoRCxRQUFPLFVBRVAsaUNBQUMsWUFDRztBQUFBLGlDQUFDLFNBQUksS0FBS3JCLGVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQTtBQUFBLGFBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsWUFDRyxTQUFTLE1BQU07QUFDWFksMkJBQWlCSCxPQUFPO0FBQUEsUUFDNUIsR0FFQTtBQUFBLGlDQUFDLFNBQUksS0FBS1IsWUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBO0FBQUEsYUFMdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLFNBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRVI7QUFBQ08sR0E1Q2VGLGtCQUFnQjtBQUFBLFVBRVhKLFVBQVU7QUFBQTtBQUFBb0IsS0FGZmhCO0FBQWdCLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiUkVNT1ZFX0lDT04iLCJCQUdfSUNPTiIsInVzZUZldGNoZXIiLCJQcmljZSIsInVzZUNvbnRleHQiLCJDYXJ0Q29udGV4dCIsIkZhdm91cml0ZVByb2R1Y3QiLCJmYXZvdXJpdGUiLCJfcyIsInByb2R1Y3QiLCJGb3JtIiwicHJpY2UiLCJhZGRQcm9kdWN0VG9DYXJ0IiwiZmF2b3VyaXRlUHJvZHVjdCIsInBob3RvcyIsImZhdm91cml0ZVByb2R1Y3RJbmZvIiwidG9wUm93IiwiYnJhbmQiLCJwcm9kdWN0TmFtZSIsInByaWNlUm93IiwiYnV0dG9uUm93IiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZhdm91cml0ZVByb2R1Y3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vRmF2b3VyaXRlUHJvZHVjdC5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgUkVNT1ZFX0lDT04gZnJvbSBcIi4uLy4uL2Fzc2V0cy9yZW1vdmUuc3ZnXCI7XG5pbXBvcnQgQkFHX0lDT04gZnJvbSBcIi4uLy4uL2Fzc2V0cy9iYWcuc3ZnXCI7XG5pbXBvcnQgeyB1c2VGZXRjaGVyIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IFByaWNlIH0gZnJvbSBcIi4uL1ByaWNlL1ByaWNlXCI7XG5pbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDYXJ0Q29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0cy9DYXJ0Q29udGV4dFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gRmF2b3VyaXRlUHJvZHVjdCh7IGZhdm91cml0ZSB9KSB7XG4gICAgY29uc3QgcHJvZHVjdCA9IGZhdm91cml0ZS5wcm9kdWN0O1xuICAgIGNvbnN0IHsgRm9ybSB9ID0gdXNlRmV0Y2hlcigpO1xuXG4gICAgY29uc3QgcHJpY2UgPSA8UHJpY2UgcHJvZHVjdD17cHJvZHVjdH0gLz47XG5cbiAgICBjb25zdCBbLCBhZGRQcm9kdWN0VG9DYXJ0XSA9IHVzZUNvbnRleHQoQ2FydENvbnRleHQpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5mYXZvdXJpdGVQcm9kdWN0fT5cbiAgICAgICAgICAgIDxpbWcgc3JjPXtwcm9kdWN0LnBob3Rvc1swXX0gLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZmF2b3VyaXRlUHJvZHVjdEluZm99PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudG9wUm93fT5cbiAgICAgICAgICAgICAgICAgICAgPGgzPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Byb2R1Y3QuYnJhbmR9IHtwcm9kdWN0LnByb2R1Y3ROYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cD57cHJpY2V9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17c3R5bGVzLnByaWNlUm93fT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q2VuYTogPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7cHJpY2V9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9uUm93fT5cbiAgICAgICAgICAgICAgICAgICAgPEZvcm1cbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbj17YC9kZWxldGUtZnJvbS1mYXZvdXJpdGVzLyR7ZmF2b3VyaXRlLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q9XCJERUxFVEVcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtSRU1PVkVfSUNPTn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBVc3XFhFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZFByb2R1Y3RUb0NhcnQocHJvZHVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17QkFHX0lDT059IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBEb2RhaiBkbyBrb3N6eWthXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvRmF2b3VyaXRlUHJvZHVjdC9GYXZvdXJpdGVQcm9kdWN0LmpzeCJ9