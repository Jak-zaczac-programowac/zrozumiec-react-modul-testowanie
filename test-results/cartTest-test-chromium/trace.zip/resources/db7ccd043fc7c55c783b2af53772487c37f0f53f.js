import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CurrencySelector/CurrencySelector.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CurrencySelector/CurrencySelector.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/CurrencySelector/CurrencySelector.module.css";
import { CURRENCIES } from "/src/constants/currencies.js";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=6c826b96"; const useContext = __vite__cjsImport5_react["useContext"];
import { CurrencyContext } from "/src/contexts/CurrencyContext.js";
export function CurrencySelector() {
  _s();
  const [currency, setCurrency] = useContext(CurrencyContext);
  return /* @__PURE__ */ jsxDEV("select", { value: currency, onChange: (e) => {
    setCurrency(e.currentTarget.value);
  }, className: styles.currencySelector, children: [
    /* @__PURE__ */ jsxDEV("option", { value: CURRENCIES.PLN, children: CURRENCIES.PLN }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CurrencySelector/CurrencySelector.jsx",
      lineNumber: 12,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("option", { value: CURRENCIES.USD, children: CURRENCIES.USD }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CurrencySelector/CurrencySelector.jsx",
      lineNumber: 13,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CurrencySelector/CurrencySelector.jsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
}
_s(CurrencySelector, "L5ZtYd5v/0oXAsDDFNIx0XBKgyg=");
_c = CurrencySelector;
var _c;
$RefreshReg$(_c, "CurrencySelector");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CurrencySelector/CurrencySelector.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCWixPQUFPQSxZQUFZO0FBQ25CLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsdUJBQXVCO0FBRXpCLGdCQUFTQyxtQkFBbUI7QUFBQUMsS0FBQTtBQUMvQixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUwsV0FBV0MsZUFBZTtBQUUxRCxTQUNJLHVCQUFDLFlBQ0csT0FBT0csVUFDUCxVQUFXRSxPQUFNO0FBQ2JELGdCQUFZQyxFQUFFQyxjQUFjQyxLQUFLO0FBQUEsRUFDckMsR0FDQSxXQUFXVixPQUFPVyxrQkFFbEI7QUFBQSwyQkFBQyxZQUFPLE9BQU9WLFdBQVdXLEtBQU1YLHFCQUFXVyxPQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStDO0FBQUEsSUFDL0MsdUJBQUMsWUFBTyxPQUFPWCxXQUFXWSxLQUFNWixxQkFBV1ksT0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLE9BUm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVSO0FBQUNSLEdBZmVELGtCQUFnQjtBQUFBVSxLQUFoQlY7QUFBZ0IsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlcyIsIkNVUlJFTkNJRVMiLCJ1c2VDb250ZXh0IiwiQ3VycmVuY3lDb250ZXh0IiwiQ3VycmVuY3lTZWxlY3RvciIsIl9zIiwiY3VycmVuY3kiLCJzZXRDdXJyZW5jeSIsImUiLCJjdXJyZW50VGFyZ2V0IiwidmFsdWUiLCJjdXJyZW5jeVNlbGVjdG9yIiwiUExOIiwiVVNEIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDdXJyZW5jeVNlbGVjdG9yLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0N1cnJlbmN5U2VsZWN0b3IubW9kdWxlLmNzc1wiO1xuaW1wb3J0IHsgQ1VSUkVOQ0lFUyB9IGZyb20gXCIuLi8uLi9jb25zdGFudHMvY3VycmVuY2llc1wiO1xuaW1wb3J0IHsgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ3VycmVuY3lDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0N1cnJlbmN5Q29udGV4dFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gQ3VycmVuY3lTZWxlY3RvcigpIHtcbiAgICBjb25zdCBbY3VycmVuY3ksIHNldEN1cnJlbmN5XSA9IHVzZUNvbnRleHQoQ3VycmVuY3lDb250ZXh0KTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgIHZhbHVlPXtjdXJyZW5jeX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIHNldEN1cnJlbmN5KGUuY3VycmVudFRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuY3VycmVuY3lTZWxlY3Rvcn1cbiAgICAgICAgPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17Q1VSUkVOQ0lFUy5QTE59PntDVVJSRU5DSUVTLlBMTn08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e0NVUlJFTkNJRVMuVVNEfT57Q1VSUkVOQ0lFUy5VU0R9PC9vcHRpb24+XG4gICAgICAgIDwvc2VsZWN0PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi9yZWFjdC1jb3Vyc2UvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvQ3VycmVuY3lTZWxlY3Rvci9DdXJyZW5jeVNlbGVjdG9yLmpzeCJ9