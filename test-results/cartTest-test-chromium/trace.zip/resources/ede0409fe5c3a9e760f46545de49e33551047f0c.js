import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CartProduct/CartProduct.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6c826b96"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/CartProduct/CartProduct.module.css";
import REMOVE_ICON from "/src/assets/remove.svg?import";
import { Price } from "/src/components/Price/Price.jsx";
export function CartProduct({
  product
}) {
  const price = /* @__PURE__ */ jsxDEV(Price, { product }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
    lineNumber: 7,
    columnNumber: 17
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.favouriteProduct, children: [
    /* @__PURE__ */ jsxDEV("img", { src: product.photos[0] }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
      lineNumber: 9,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.favouriteProductInfo, children: [
      /* @__PURE__ */ jsxDEV("div", { className: styles.topRow, children: [
        /* @__PURE__ */ jsxDEV("h3", { children: [
          product.brand,
          " ",
          product.productName
        ] }, void 0, true, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
          lineNumber: 12,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: price }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
          lineNumber: 15,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
        lineNumber: 11,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: styles.priceRow, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Cena: " }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
          lineNumber: 18,
          columnNumber: 21
        }, this),
        price
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
        lineNumber: 17,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: styles.buttonRow, children: /* @__PURE__ */ jsxDEV("button", { children: [
        /* @__PURE__ */ jsxDEV("img", { src: REMOVE_ICON }, void 0, false, {
          fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
          lineNumber: 23,
          columnNumber: 25
        }, this),
        "Usuń"
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
        lineNumber: 22,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
        lineNumber: 21,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
      lineNumber: 10,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = CartProduct;
var _c;
$RefreshReg$(_c, "CartProduct");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/react-course/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProduct/CartProduct.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS2tCO0FBTGxCLE9BQU9BLG9CQUFZO0FBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUM3QyxPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0MsYUFBYTtBQUVmLGdCQUFTQyxZQUFZO0FBQUEsRUFBRUM7QUFBUSxHQUFHO0FBQ3JDLFFBQU1DLFFBQVEsdUJBQUMsU0FBTSxXQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0I7QUFFdEMsU0FDSSx1QkFBQyxTQUFJLFdBQVdMLE9BQU9NLGtCQUNuQjtBQUFBLDJCQUFDLFNBQUksS0FBS0YsUUFBUUcsT0FBTyxDQUFDLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxJQUM1Qix1QkFBQyxTQUFJLFdBQVdQLE9BQU9RLHNCQUNuQjtBQUFBLDZCQUFDLFNBQUksV0FBV1IsT0FBT1MsUUFDbkI7QUFBQSwrQkFBQyxRQUNJTDtBQUFBQSxrQkFBUU07QUFBQUEsVUFBTTtBQUFBLFVBQUVOLFFBQVFPO0FBQUFBLGFBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBR04sbUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFVO0FBQUEsV0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBV0wsT0FBT1ksVUFDakI7QUFBQSwrQkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQ1hQO0FBQUFBLFdBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVdMLE9BQU9hLFdBQ25CLGlDQUFDLFlBQ0c7QUFBQSwrQkFBQyxTQUFJLEtBQUtaLGVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBO0FBQUEsV0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkE7QUFFUjtBQUFDYSxLQTFCZVg7QUFBVyxJQUFBVztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiUkVNT1ZFX0lDT04iLCJQcmljZSIsIkNhcnRQcm9kdWN0IiwicHJvZHVjdCIsInByaWNlIiwiZmF2b3VyaXRlUHJvZHVjdCIsInBob3RvcyIsImZhdm91cml0ZVByb2R1Y3RJbmZvIiwidG9wUm93IiwiYnJhbmQiLCJwcm9kdWN0TmFtZSIsInByaWNlUm93IiwiYnV0dG9uUm93IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYXJ0UHJvZHVjdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9DYXJ0UHJvZHVjdC5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgUkVNT1ZFX0lDT04gZnJvbSBcIi4uLy4uL2Fzc2V0cy9yZW1vdmUuc3ZnXCI7XG5pbXBvcnQgeyBQcmljZSB9IGZyb20gXCIuLi9QcmljZS9QcmljZVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gQ2FydFByb2R1Y3QoeyBwcm9kdWN0IH0pIHtcbiAgICBjb25zdCBwcmljZSA9IDxQcmljZSBwcm9kdWN0PXtwcm9kdWN0fSAvPjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZmF2b3VyaXRlUHJvZHVjdH0+XG4gICAgICAgICAgICA8aW1nIHNyYz17cHJvZHVjdC5waG90b3NbMF19IC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZhdm91cml0ZVByb2R1Y3RJbmZvfT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnRvcFJvd30+XG4gICAgICAgICAgICAgICAgICAgIDxoMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0LmJyYW5kfSB7cHJvZHVjdC5wcm9kdWN0TmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHA+e3ByaWNlfTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5wcmljZVJvd30+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNlbmE6IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge3ByaWNlfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmJ1dHRvblJvd30+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17UkVNT1ZFX0lDT059IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBVc3XFhFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMva2FjcGVyc29rb2xvd3NraS9kZXYvcmVhY3QtY291cnNlL3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL0NhcnRQcm9kdWN0L0NhcnRQcm9kdWN0LmpzeCJ9