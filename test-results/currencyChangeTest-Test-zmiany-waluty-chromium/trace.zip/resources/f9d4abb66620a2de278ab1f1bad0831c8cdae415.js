import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CartSummary/CartSummary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/CartSummary/CartSummary.module.css";
import { FullWidthButton } from "/src/components/FullWidthButton/FullWidthButton.jsx";
import CAR_ICON from "/src/assets/car.svg?import";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=6df970d1"; const useContext = __vite__cjsImport6_react["useContext"];
import { CurrencyContext } from "/src/contexts/CurrencyContext.js";
import { CURRENCIES, CURRENCY_SIGN } from "/src/constants/currencies.js";
export function HelloReact({
  name
}) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Komponent Reactowy!" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 12,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      "Witaj ",
      name,
      "!"
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 13,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_c = HelloReact;
export function CartSummary({
  products
}) {
  _s();
  const [currency] = useContext(CurrencyContext);
  const deliveryCosts = {
    [CURRENCIES.USD]: 10,
    [CURRENCIES.PLN]: 49
  };
  const minSumsForFreeDelivery = {
    [CURRENCIES.USD]: 100,
    [CURRENCIES.PLN]: 500
  };
  const currencySign = CURRENCY_SIGN[currency];
  const deliveryCost = deliveryCosts[currency];
  const minSumForFreeDelivery = minSumsForFreeDelivery[currency];
  let sum = 0;
  products.forEach((product) => {
    sum += currency === CURRENCIES.PLN ? product.pricePLN : product.priceUSD;
  });
  const totalCost = sum > minSumForFreeDelivery ? sum : sum + deliveryCost;
  return /* @__PURE__ */ jsxDEV("div", { className: styles.cartSummary, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Podsumowanie" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 39,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.cartRow, children: [
      /* @__PURE__ */ jsxDEV("p", { children: "Wartość produktów: " }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 41,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        sum,
        currencySign
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 42,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 40,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.cartRow, children: [
      /* @__PURE__ */ jsxDEV("p", { children: "Koszt dostawy:" }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 48,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        sum > minSumForFreeDelivery ? 0 : deliveryCost,
        currencySign
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 49,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 47,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `${styles.cartRow} ${styles.cartSummaryRow}`, children: [
      /* @__PURE__ */ jsxDEV("p", { children: "Do zapłaty:" }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 55,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        totalCost,
        currencySign
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 56,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 54,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FullWidthButton, { isBlack: true, children: "Do kasy" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 61,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.deliveryInfo, children: [
      /* @__PURE__ */ jsxDEV("img", { src: CAR_ICON }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 63,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Darmowa dostawa od ",
        minSumForFreeDelivery,
        currencySign
      ] }, void 0, true, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
        lineNumber: 64,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
      lineNumber: 62,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx",
    lineNumber: 38,
    columnNumber: 10
  }, this);
}
_s(CartSummary, "ZbDfdLMxfWGE+8eHwtZKYbUXdY8=");
_c2 = CartSummary;
var _c, _c2;
$RefreshReg$(_c, "HelloReact");
$RefreshReg$(_c2, "CartSummary");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartSummary/CartSummary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVEsbUJBQ0ksY0FESjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWUixPQUFPQSxZQUFZO0FBRW5CLFNBQVNDLHVCQUF1QjtBQUNoQyxPQUFPQyxjQUFjO0FBQ3JCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsWUFBWUMscUJBQXFCO0FBRW5DLGdCQUFTQyxXQUFXO0FBQUEsRUFBRUM7QUFBSyxHQUFHO0FBQ2pDLFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxJQUN2Qix1QkFBQyxPQUFFO0FBQUE7QUFBQSxNQUFPQTtBQUFBQSxNQUFLO0FBQUEsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCO0FBQUEsT0FGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRVI7QUFBQ0MsS0FQZUY7QUFTVCxnQkFBU0csWUFBWTtBQUFBLEVBQUVDO0FBQVMsR0FBRztBQUFBQyxLQUFBO0FBQ3RDLFFBQU0sQ0FBQ0MsUUFBUSxJQUFJVixXQUFXQyxlQUFlO0FBRTdDLFFBQU1VLGdCQUFnQjtBQUFBLElBQ2xCLENBQUNULFdBQVdVLEdBQUcsR0FBRztBQUFBLElBQ2xCLENBQUNWLFdBQVdXLEdBQUcsR0FBRztBQUFBLEVBQ3RCO0FBRUEsUUFBTUMseUJBQXlCO0FBQUEsSUFDM0IsQ0FBQ1osV0FBV1UsR0FBRyxHQUFHO0FBQUEsSUFDbEIsQ0FBQ1YsV0FBV1csR0FBRyxHQUFHO0FBQUEsRUFDdEI7QUFFQSxRQUFNRSxlQUFlWixjQUFjTyxRQUFRO0FBRTNDLFFBQU1NLGVBQWVMLGNBQWNELFFBQVE7QUFDM0MsUUFBTU8sd0JBQXdCSCx1QkFBdUJKLFFBQVE7QUFFN0QsTUFBSVEsTUFBTTtBQUNWVixXQUFTVyxRQUFTQyxhQUFZO0FBQzFCRixXQUNJUixhQUFhUixXQUFXVyxNQUFNTyxRQUFRQyxXQUFXRCxRQUFRRTtBQUFBQSxFQUNqRSxDQUFDO0FBRUQsUUFBTUMsWUFBWUwsTUFBTUQsd0JBQXdCQyxNQUFNQSxNQUFNRjtBQUU1RCxTQUNJLHVCQUFDLFNBQUksV0FBV25CLE9BQU8yQixhQUNuQjtBQUFBLDJCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ2hCLHVCQUFDLFNBQUksV0FBVzNCLE9BQU80QixTQUNuQjtBQUFBLDZCQUFDLE9BQUUsbUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQjtBQUFBLE1BQ3RCLHVCQUFDLE9BQ0lQO0FBQUFBO0FBQUFBLFFBQ0FIO0FBQUFBLFdBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV2xCLE9BQU80QixTQUNuQjtBQUFBLDZCQUFDLE9BQUUsOEJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCLHVCQUFDLE9BQ0lQO0FBQUFBLGNBQU1ELHdCQUF3QixJQUFJRDtBQUFBQSxRQUNsQ0Q7QUFBQUEsV0FGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFZLEdBQUVsQixPQUFPNEIsT0FBUSxJQUFHNUIsT0FBTzZCLGNBQWUsSUFDdkQ7QUFBQSw2QkFBQyxPQUFFLDJCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYztBQUFBLE1BQ2QsdUJBQUMsT0FDSUg7QUFBQUE7QUFBQUEsUUFDQVI7QUFBQUEsV0FGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsbUJBQWdCLFNBQVMsTUFBTSx1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLElBQ3ZDLHVCQUFDLFNBQUksV0FBV2xCLE9BQU84QixjQUNuQjtBQUFBLDZCQUFDLFNBQUksS0FBSzVCLFlBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLE1BQ25CLHVCQUFDLE9BQUM7QUFBQTtBQUFBLFFBQ3NCa0I7QUFBQUEsUUFDbkJGO0FBQUFBLFdBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0JBO0FBRVI7QUFBQ04sR0E1RGVGLGFBQVc7QUFBQXFCLE1BQVhyQjtBQUFXLElBQUFELElBQUFzQjtBQUFBQyxhQUFBdkIsSUFBQTtBQUFBdUIsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInN0eWxlcyIsIkZ1bGxXaWR0aEJ1dHRvbiIsIkNBUl9JQ09OIiwidXNlQ29udGV4dCIsIkN1cnJlbmN5Q29udGV4dCIsIkNVUlJFTkNJRVMiLCJDVVJSRU5DWV9TSUdOIiwiSGVsbG9SZWFjdCIsIm5hbWUiLCJfYyIsIkNhcnRTdW1tYXJ5IiwicHJvZHVjdHMiLCJfcyIsImN1cnJlbmN5IiwiZGVsaXZlcnlDb3N0cyIsIlVTRCIsIlBMTiIsIm1pblN1bXNGb3JGcmVlRGVsaXZlcnkiLCJjdXJyZW5jeVNpZ24iLCJkZWxpdmVyeUNvc3QiLCJtaW5TdW1Gb3JGcmVlRGVsaXZlcnkiLCJzdW0iLCJmb3JFYWNoIiwicHJvZHVjdCIsInByaWNlUExOIiwicHJpY2VVU0QiLCJ0b3RhbENvc3QiLCJjYXJ0U3VtbWFyeSIsImNhcnRSb3ciLCJjYXJ0U3VtbWFyeVJvdyIsImRlbGl2ZXJ5SW5mbyIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNhcnRTdW1tYXJ5LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0NhcnRTdW1tYXJ5Lm1vZHVsZS5jc3NcIjtcblxuaW1wb3J0IHsgRnVsbFdpZHRoQnV0dG9uIH0gZnJvbSBcIi4uL0Z1bGxXaWR0aEJ1dHRvbi9GdWxsV2lkdGhCdXR0b25cIjtcbmltcG9ydCBDQVJfSUNPTiBmcm9tIFwiLi4vLi4vYXNzZXRzL2Nhci5zdmdcIjtcbmltcG9ydCB7IHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEN1cnJlbmN5Q29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0cy9DdXJyZW5jeUNvbnRleHRcIjtcbmltcG9ydCB7IENVUlJFTkNJRVMsIENVUlJFTkNZX1NJR04gfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL2N1cnJlbmNpZXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEhlbGxvUmVhY3QoeyBuYW1lIH0pIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAgPGgxPktvbXBvbmVudCBSZWFjdG93eSE8L2gxPlxuICAgICAgICAgICAgPHA+V2l0YWoge25hbWV9ITwvcD5cbiAgICAgICAgPC8+XG4gICAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENhcnRTdW1tYXJ5KHsgcHJvZHVjdHMgfSkge1xuICAgIGNvbnN0IFtjdXJyZW5jeV0gPSB1c2VDb250ZXh0KEN1cnJlbmN5Q29udGV4dCk7XG5cbiAgICBjb25zdCBkZWxpdmVyeUNvc3RzID0ge1xuICAgICAgICBbQ1VSUkVOQ0lFUy5VU0RdOiAxMCxcbiAgICAgICAgW0NVUlJFTkNJRVMuUExOXTogNDksXG4gICAgfTtcblxuICAgIGNvbnN0IG1pblN1bXNGb3JGcmVlRGVsaXZlcnkgPSB7XG4gICAgICAgIFtDVVJSRU5DSUVTLlVTRF06IDEwMCxcbiAgICAgICAgW0NVUlJFTkNJRVMuUExOXTogNTAwLFxuICAgIH07XG5cbiAgICBjb25zdCBjdXJyZW5jeVNpZ24gPSBDVVJSRU5DWV9TSUdOW2N1cnJlbmN5XTtcblxuICAgIGNvbnN0IGRlbGl2ZXJ5Q29zdCA9IGRlbGl2ZXJ5Q29zdHNbY3VycmVuY3ldO1xuICAgIGNvbnN0IG1pblN1bUZvckZyZWVEZWxpdmVyeSA9IG1pblN1bXNGb3JGcmVlRGVsaXZlcnlbY3VycmVuY3ldO1xuXG4gICAgbGV0IHN1bSA9IDA7XG4gICAgcHJvZHVjdHMuZm9yRWFjaCgocHJvZHVjdCkgPT4ge1xuICAgICAgICBzdW0gKz1cbiAgICAgICAgICAgIGN1cnJlbmN5ID09PSBDVVJSRU5DSUVTLlBMTiA/IHByb2R1Y3QucHJpY2VQTE4gOiBwcm9kdWN0LnByaWNlVVNEO1xuICAgIH0pO1xuXG4gICAgY29uc3QgdG90YWxDb3N0ID0gc3VtID4gbWluU3VtRm9yRnJlZURlbGl2ZXJ5ID8gc3VtIDogc3VtICsgZGVsaXZlcnlDb3N0O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jYXJ0U3VtbWFyeX0+XG4gICAgICAgICAgICA8aDI+UG9kc3Vtb3dhbmllPC9oMj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY2FydFJvd30+XG4gICAgICAgICAgICAgICAgPHA+V2FydG/Fm8SHIHByb2R1a3TDs3c6IDwvcD5cbiAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAge3N1bX1cbiAgICAgICAgICAgICAgICAgICAge2N1cnJlbmN5U2lnbn1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY2FydFJvd30+XG4gICAgICAgICAgICAgICAgPHA+S29zenQgZG9zdGF3eTo8L3A+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgIHtzdW0gPiBtaW5TdW1Gb3JGcmVlRGVsaXZlcnkgPyAwIDogZGVsaXZlcnlDb3N0fVxuICAgICAgICAgICAgICAgICAgICB7Y3VycmVuY3lTaWdufVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake3N0eWxlcy5jYXJ0Um93fSAke3N0eWxlcy5jYXJ0U3VtbWFyeVJvd31gfT5cbiAgICAgICAgICAgICAgICA8cD5EbyB6YXDFgmF0eTo8L3A+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgIHt0b3RhbENvc3R9XG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW5jeVNpZ259XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8RnVsbFdpZHRoQnV0dG9uIGlzQmxhY2s9e3RydWV9PkRvIGthc3k8L0Z1bGxXaWR0aEJ1dHRvbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZGVsaXZlcnlJbmZvfT5cbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17Q0FSX0lDT059IC8+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgIERhcm1vd2EgZG9zdGF3YSBvZCB7bWluU3VtRm9yRnJlZURlbGl2ZXJ5fVxuICAgICAgICAgICAgICAgICAgICB7Y3VycmVuY3lTaWdufVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMva2FjcGVyc29rb2xvd3NraS9kZXYvenJvenVtaWVjLXJlYWN0LW1vZHVsLXByYWt0eWN6bnktcHJvamVrdC9mcm9udC1lbmQvc3JjL2NvbXBvbmVudHMvQ2FydFN1bW1hcnkvQ2FydFN1bW1hcnkuanN4In0=