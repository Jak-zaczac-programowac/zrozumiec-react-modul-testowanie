import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CartProductsList/CartProductsList.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.module.css"
const __vite__css = "._favouritesList_1j7tk_1 {\n    padding: 1rem;\n    background-color: var(--color-grey);\n    margin-top: 1rem;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const favouritesList = "_favouritesList_1j7tk_1";
export default {
	favouritesList: favouritesList
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))