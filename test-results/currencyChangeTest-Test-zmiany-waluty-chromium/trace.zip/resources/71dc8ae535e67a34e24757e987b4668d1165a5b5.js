import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Products/Products.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Products/Products.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/Products/Products.module.css";
import { CenteredContent } from "/src/components/CenteredContent/CenteredContent.jsx";
import { Product } from "/src/components/Product/Product.jsx";
export function Products({
  products,
  headerText
}) {
  return /* @__PURE__ */ jsxDEV(CenteredContent, { children: [
    /* @__PURE__ */ jsxDEV("h2", { className: styles.bestsellersHeader, children: headerText }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Products/Products.jsx",
      lineNumber: 9,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.productsWrapper, children: products.map((product) => {
      return /* @__PURE__ */ jsxDEV(Product, { product }, product.id, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Products/Products.jsx",
        lineNumber: 12,
        columnNumber: 16
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Products/Products.jsx",
      lineNumber: 10,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Products/Products.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = Products;
var _c;
$RefreshReg$(_c, "Products");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Products/Products.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1k7QUFQWixPQUFPQSxvQkFBWTtBQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDMUMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGVBQWU7QUFFakIsZ0JBQVNDLFNBQVM7QUFBQSxFQUFFQztBQUFBQSxFQUFVQztBQUFXLEdBQUc7QUFDL0MsU0FDSSx1QkFBQyxtQkFDRztBQUFBLDJCQUFDLFFBQUcsV0FBV0wsT0FBT00sbUJBQW9CRCx3QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLElBQ3JELHVCQUFDLFNBQUksV0FBV0wsT0FBT08saUJBQ2xCSCxtQkFBU0ksSUFBS0MsYUFBWTtBQUN2QixhQUFPLHVCQUFDLFdBQXlCLFdBQVpBLFFBQVFDLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxJQUN0RCxDQUFDLEtBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFUjtBQUFDQyxLQVhlUjtBQUFRLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJzdHlsZXMiLCJDZW50ZXJlZENvbnRlbnQiLCJQcm9kdWN0IiwiUHJvZHVjdHMiLCJwcm9kdWN0cyIsImhlYWRlclRleHQiLCJiZXN0c2VsbGVyc0hlYWRlciIsInByb2R1Y3RzV3JhcHBlciIsIm1hcCIsInByb2R1Y3QiLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvZHVjdHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vUHJvZHVjdHMubW9kdWxlLmNzc1wiO1xuaW1wb3J0IHsgQ2VudGVyZWRDb250ZW50IH0gZnJvbSBcIi4uL0NlbnRlcmVkQ29udGVudC9DZW50ZXJlZENvbnRlbnRcIjtcbmltcG9ydCB7IFByb2R1Y3QgfSBmcm9tIFwiLi4vUHJvZHVjdC9Qcm9kdWN0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0cyh7IHByb2R1Y3RzLCBoZWFkZXJUZXh0IH0pIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8Q2VudGVyZWRDb250ZW50PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT17c3R5bGVzLmJlc3RzZWxsZXJzSGVhZGVyfT57aGVhZGVyVGV4dH08L2gyPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0c1dyYXBwZXJ9PlxuICAgICAgICAgICAgICAgIHtwcm9kdWN0cy5tYXAoKHByb2R1Y3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxQcm9kdWN0IGtleT17cHJvZHVjdC5pZH0gcHJvZHVjdD17cHJvZHVjdH0gLz47XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DZW50ZXJlZENvbnRlbnQ+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL1Byb2R1Y3RzL1Byb2R1Y3RzLmpzeCJ9