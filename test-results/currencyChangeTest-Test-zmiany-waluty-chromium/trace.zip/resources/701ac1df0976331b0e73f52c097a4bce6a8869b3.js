import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/IconMenu/IconMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/IconMenu/IconMenu.module.css";
import BAG_ICON from "/src/assets/bag.svg?import";
import HEART from "/src/assets/heart.svg?import";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=db5b57d4";
export function IconMenu() {
  const cartItems = 2;
  return /* @__PURE__ */ jsxDEV("ul", { className: styles.iconMenu, children: [
    /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/ulubione", children: /* @__PURE__ */ jsxDEV("img", { src: HEART }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
      lineNumber: 10,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
      lineNumber: 9,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
      lineNumber: 8,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/koszyk", children: [
      /* @__PURE__ */ jsxDEV("img", { src: BAG_ICON }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
        lineNumber: 15,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: styles.numberOfProducts, children: cartItems }, void 0, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
        lineNumber: 16,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
      lineNumber: 14,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
      lineNumber: 13,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = IconMenu;
var _c;
$RefreshReg$(_c, "IconMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYW9CO0FBYnBCLE9BQU9BLG9CQUFZO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQyxPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLFdBQVc7QUFFbEIsU0FBU0MsWUFBWTtBQUVkLGdCQUFTQyxXQUFXO0FBQ3ZCLFFBQU1DLFlBQVk7QUFFbEIsU0FDSSx1QkFBQyxRQUFHLFdBQVdMLE9BQU9NLFVBQ2xCO0FBQUEsMkJBQUMsUUFDRyxpQ0FBQyxRQUFLLElBQUcsYUFDTCxpQ0FBQyxTQUFJLEtBQUtKLFNBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFFBQ0csaUNBQUMsUUFBSyxJQUFHLFdBQ0w7QUFBQSw2QkFBQyxTQUFJLEtBQUtELFlBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLE1BQ25CLHVCQUFDLFNBQUksV0FBV0QsT0FBT08sa0JBQW1CRix1QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLFNBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRVI7QUFBQ0csS0FsQmVKO0FBQVEsSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlcyIsIkJBR19JQ09OIiwiSEVBUlQiLCJMaW5rIiwiSWNvbk1lbnUiLCJjYXJ0SXRlbXMiLCJpY29uTWVudSIsIm51bWJlck9mUHJvZHVjdHMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkljb25NZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0ljb25NZW51Lm1vZHVsZS5jc3NcIjtcbmltcG9ydCBCQUdfSUNPTiBmcm9tIFwiLi4vLi4vYXNzZXRzL2JhZy5zdmdcIjtcbmltcG9ydCBIRUFSVCBmcm9tIFwiLi4vLi4vYXNzZXRzL2hlYXJ0LnN2Z1wiO1xuXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEljb25NZW51KCkge1xuICAgIGNvbnN0IGNhcnRJdGVtcyA9IDI7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8dWwgY2xhc3NOYW1lPXtzdHlsZXMuaWNvbk1lbnV9PlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3VsdWJpb25lXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtIRUFSVH0gLz5cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2tvc3p5a1wiPlxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17QkFHX0lDT059IC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubnVtYmVyT2ZQcm9kdWN0c30+e2NhcnRJdGVtc308L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICA8L3VsPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9JY29uTWVudS9JY29uTWVudS5qc3gifQ==