import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Pagination/Pagination.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Pagination/Pagination.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/Pagination/Pagination.module.css";
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=db5b57d4";
export function Pagination({
  numberOfPages
}) {
  const pages = Array(numberOfPages).fill(null);
  return /* @__PURE__ */ jsxDEV("ul", { className: styles.pagination, children: pages.map((page, index) => {
    return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(NavLink, { to: `?page=${index + 1}`, children: index + 1 }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Pagination/Pagination.jsx",
      lineNumber: 10,
      columnNumber: 25
    }, this) }, index, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Pagination/Pagination.jsx",
      lineNumber: 9,
      columnNumber: 14
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Pagination/Pagination.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Pagination/Pagination.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCO0FBVnhCLE9BQU9BLG9CQUFZO0FBQXlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUU1QyxTQUFTQyxlQUFlO0FBQ2pCLGdCQUFTQyxXQUFXO0FBQUEsRUFBRUM7QUFBYyxHQUFHO0FBQzFDLFFBQU1DLFFBQVFDLE1BQU1GLGFBQWEsRUFBRUcsS0FBSyxJQUFJO0FBQzVDLFNBQ0ksdUJBQUMsUUFBRyxXQUFXTixPQUFPTyxZQUNqQkgsZ0JBQU1JLElBQUksQ0FBQ0MsTUFBTUMsVUFBVTtBQUN4QixXQUNJLHVCQUFDLFFBQ0csaUNBQUMsV0FBUSxJQUFLLFNBQVFBLFFBQVEsQ0FBRSxJQUFJQSxrQkFBUSxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDLEtBRHpDQSxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRVIsQ0FBQyxLQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVSO0FBQUNDLEtBYmVUO0FBQVUsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlcyIsIk5hdkxpbmsiLCJQYWdpbmF0aW9uIiwibnVtYmVyT2ZQYWdlcyIsInBhZ2VzIiwiQXJyYXkiLCJmaWxsIiwicGFnaW5hdGlvbiIsIm1hcCIsInBhZ2UiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGFnaW5hdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9QYWdpbmF0aW9uLm1vZHVsZS5jc3NcIjtcblxuaW1wb3J0IHsgTmF2TGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5leHBvcnQgZnVuY3Rpb24gUGFnaW5hdGlvbih7IG51bWJlck9mUGFnZXMgfSkge1xuICAgIGNvbnN0IHBhZ2VzID0gQXJyYXkobnVtYmVyT2ZQYWdlcykuZmlsbChudWxsKTtcbiAgICByZXR1cm4gKFxuICAgICAgICA8dWwgY2xhc3NOYW1lPXtzdHlsZXMucGFnaW5hdGlvbn0+XG4gICAgICAgICAgICB7cGFnZXMubWFwKChwYWdlLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2luZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIHRvPXtgP3BhZ2U9JHtpbmRleCArIDF9YH0+e2luZGV4ICsgMX08L05hdkxpbms+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICA8L3VsPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9QYWdpbmF0aW9uL1BhZ2luYXRpb24uanN4In0=