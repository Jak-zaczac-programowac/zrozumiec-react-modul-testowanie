import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CenteredContent/CenteredContent.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CenteredContent/CenteredContent.module.css"
const __vite__css = "._wrapper_fg6n0_1 {\n    width: 100%;\n    max-width: 100rem;\n    margin: 0 auto;\n    padding: 0 1rem;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const wrapper = "_wrapper_fg6n0_1";
export default {
	wrapper: wrapper
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))