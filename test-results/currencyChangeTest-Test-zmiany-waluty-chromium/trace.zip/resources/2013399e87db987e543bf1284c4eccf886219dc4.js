import { redirect } from "/node_modules/.vite/deps/react-router-dom.js?v=db5b57d4";
import { PATH_TO_ENDPOINT_MAPPING, BACK_END_URL } from "/src/constants/api.js";

export function mainPageLoader({ params }) {
    const backEndPath = PATH_TO_ENDPOINT_MAPPING[params.gender];
    if (backEndPath) {
        return fetch(`${BACK_END_URL}/${backEndPath}`);
    } else {
        return redirect("/kobieta");
    }
}
