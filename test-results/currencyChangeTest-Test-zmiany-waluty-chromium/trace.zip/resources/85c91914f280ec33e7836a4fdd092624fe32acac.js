import {
  require_react
} from "/node_modules/.vite/deps/chunk-WUJDOWEQ.js?v=ae461ef1";
export default require_react();
//# sourceMappingURL=react.js.map
