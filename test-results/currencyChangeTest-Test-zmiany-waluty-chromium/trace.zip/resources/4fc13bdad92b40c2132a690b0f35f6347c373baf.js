import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MainMenu/MainMenu.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainMenu/MainMenu.module.css"
const __vite__css = "._mainMenu_1nslj_1 {\n    display: flex;\n    align-items: center;\n    justify-content: flex-start;\n    gap: 1rem;\n    padding: 1rem;\n}\n\n._mainMenu_1nslj_1 li a {\n    text-transform: uppercase;\n    color: var(--color-text-grey);\n    padding: 1rem 0;\n    display: block;\n    font-weight: 700;\n}\n\n._mainMenu_1nslj_1 a.active {\n    color: var(--color-text-default);\n    border-bottom: 3px solid var(--color-text-default);\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const mainMenu = "_mainMenu_1nslj_1";
export default {
	mainMenu: mainMenu
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))