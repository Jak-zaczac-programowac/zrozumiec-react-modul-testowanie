import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MainContent/MainContent.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainContent/MainContent.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/MainContent/MainContent.module.css";
export function MainContent({
  children
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: styles.mainContent, children }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainContent/MainContent.jsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = MainContent;
var _c;
$RefreshReg$(_c, "MainContent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/MainContent/MainContent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR1c7QUFIWCxPQUFPQSxvQkFBWTtBQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFdEMsZ0JBQVNDLFlBQVk7QUFBQSxFQUFFQztBQUFTLEdBQUc7QUFDdEMsU0FBTyx1QkFBQyxTQUFJLFdBQVdGLE9BQU9HLGFBQWNELFlBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEM7QUFDekQ7QUFBQ0UsS0FGZUg7QUFBVyxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiTWFpbkNvbnRlbnQiLCJjaGlsZHJlbiIsIm1haW5Db250ZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNYWluQ29udGVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9NYWluQ29udGVudC5tb2R1bGUuY3NzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBNYWluQ29udGVudCh7IGNoaWxkcmVuIH0pIHtcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5tYWluQ29udGVudH0+e2NoaWxkcmVufTwvZGl2Pjtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL01haW5Db250ZW50L01haW5Db250ZW50LmpzeCJ9