export const CURRENCIES = {
    USD: "USD",
    PLN: "PLN",
};

export const CURRENCY_SIGN = {
    PLN: "zł",
    USD: "$",
};
