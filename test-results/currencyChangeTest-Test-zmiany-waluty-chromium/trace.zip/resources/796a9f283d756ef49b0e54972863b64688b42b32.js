import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CartProductsList/CartProductsList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/CartProductsList/CartProductsList.module.css";
import { CenteredContent } from "/src/components/CenteredContent/CenteredContent.jsx";
import { CartProduct } from "/src/components/CartProduct/CartProduct.jsx";
export function CartProductsList({
  products
}) {
  return /* @__PURE__ */ jsxDEV(CenteredContent, { children: /* @__PURE__ */ jsxDEV("div", { className: styles.favouritesList, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Koszyk" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx",
      lineNumber: 9,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: products.map((product) => {
      return /* @__PURE__ */ jsxDEV(CartProduct, { product }, product.id, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx",
        lineNumber: 12,
        columnNumber: 18
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx",
      lineNumber: 10,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx",
    lineNumber: 8,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = CartProductsList;
var _c;
$RefreshReg$(_c, "CartProductsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CartProductsList/CartProductsList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU2dCO0FBVGhCLE9BQU9BLG9CQUFZO0FBQUEsTUFBK0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWxELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxtQkFBbUI7QUFFckIsZ0JBQVNDLGlCQUFpQjtBQUFBLEVBQUVDO0FBQVMsR0FBRztBQUMzQyxTQUNJLHVCQUFDLG1CQUNHLGlDQUFDLFNBQUksV0FBV0osT0FBT0ssZ0JBQ25CO0FBQUEsMkJBQUMsUUFBRyxzQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVU7QUFBQSxJQUNWLHVCQUFDLFNBQ0lELG1CQUFTRSxJQUFLQyxhQUFZO0FBQ3ZCLGFBQ0ksdUJBQUMsZUFBNkIsV0FBWkEsUUFBUUMsSUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLElBRXZELENBQUMsS0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQSxLQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVSO0FBQUNDLEtBZmVOO0FBQWdCLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJzdHlsZXMiLCJDZW50ZXJlZENvbnRlbnQiLCJDYXJ0UHJvZHVjdCIsIkNhcnRQcm9kdWN0c0xpc3QiLCJwcm9kdWN0cyIsImZhdm91cml0ZXNMaXN0IiwibWFwIiwicHJvZHVjdCIsImlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYXJ0UHJvZHVjdHNMaXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0NhcnRQcm9kdWN0c0xpc3QubW9kdWxlLmNzc1wiO1xuXG5pbXBvcnQgeyBDZW50ZXJlZENvbnRlbnQgfSBmcm9tIFwiLi4vQ2VudGVyZWRDb250ZW50L0NlbnRlcmVkQ29udGVudFwiO1xuaW1wb3J0IHsgQ2FydFByb2R1Y3QgfSBmcm9tIFwiLi4vQ2FydFByb2R1Y3QvQ2FydFByb2R1Y3RcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIENhcnRQcm9kdWN0c0xpc3QoeyBwcm9kdWN0cyB9KSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPENlbnRlcmVkQ29udGVudD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZmF2b3VyaXRlc0xpc3R9PlxuICAgICAgICAgICAgICAgIDxoMj5Lb3N6eWs8L2gyPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0cy5tYXAoKHByb2R1Y3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRQcm9kdWN0IGtleT17cHJvZHVjdC5pZH0gcHJvZHVjdD17cHJvZHVjdH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2VudGVyZWRDb250ZW50PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9DYXJ0UHJvZHVjdHNMaXN0L0NhcnRQcm9kdWN0c0xpc3QuanN4In0=