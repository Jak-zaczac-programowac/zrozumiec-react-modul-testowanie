import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FavouritesList/FavouritesList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/FavouritesList/FavouritesList.module.css";
import { CenteredContent } from "/src/components/CenteredContent/CenteredContent.jsx";
import { FavouriteProduct } from "/src/components/FavouriteProduct/FavouriteProduct.jsx";
export function FavouritesList({
  favourites
}) {
  return /* @__PURE__ */ jsxDEV(CenteredContent, { children: /* @__PURE__ */ jsxDEV("div", { className: styles.favouritesList, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Ulubione" }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx",
      lineNumber: 9,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: favourites.map((favourite) => {
      return /* @__PURE__ */ jsxDEV(FavouriteProduct, { favourite }, favourite.id, false, {
        fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx",
        lineNumber: 12,
        columnNumber: 18
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx",
      lineNumber: 10,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx",
    lineNumber: 8,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = FavouritesList;
var _c;
$RefreshReg$(_c, "FavouritesList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FavouritesList/FavouritesList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU2dCO0FBVGhCLE9BQU9BLG9CQUFZO0FBQUEsTUFBNkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWhELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx3QkFBd0I7QUFFMUIsZ0JBQVNDLGVBQWU7QUFBQSxFQUFFQztBQUFXLEdBQUc7QUFDM0MsU0FDSSx1QkFBQyxtQkFDRyxpQ0FBQyxTQUFJLFdBQVdKLE9BQU9LLGdCQUNuQjtBQUFBLDJCQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQyxTQUNJRCxxQkFBV0UsSUFBS0MsZUFBYztBQUMzQixhQUNJLHVCQUFDLG9CQUVHLGFBREtBLFVBQVVDLElBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFeUI7QUFBQSxJQUdqQyxDQUFDLEtBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsT0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUEsS0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBY0E7QUFFUjtBQUFDQyxLQWxCZU47QUFBYyxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiQ2VudGVyZWRDb250ZW50IiwiRmF2b3VyaXRlUHJvZHVjdCIsIkZhdm91cml0ZXNMaXN0IiwiZmF2b3VyaXRlcyIsImZhdm91cml0ZXNMaXN0IiwibWFwIiwiZmF2b3VyaXRlIiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZhdm91cml0ZXNMaXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0Zhdm91cml0ZXNMaXN0Lm1vZHVsZS5jc3NcIjtcblxuaW1wb3J0IHsgQ2VudGVyZWRDb250ZW50IH0gZnJvbSBcIi4uL0NlbnRlcmVkQ29udGVudC9DZW50ZXJlZENvbnRlbnRcIjtcbmltcG9ydCB7IEZhdm91cml0ZVByb2R1Y3QgfSBmcm9tIFwiLi4vRmF2b3VyaXRlUHJvZHVjdC9GYXZvdXJpdGVQcm9kdWN0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBGYXZvdXJpdGVzTGlzdCh7IGZhdm91cml0ZXMgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxDZW50ZXJlZENvbnRlbnQ+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZhdm91cml0ZXNMaXN0fT5cbiAgICAgICAgICAgICAgICA8aDI+VWx1YmlvbmU8L2gyPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHtmYXZvdXJpdGVzLm1hcCgoZmF2b3VyaXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYXZvdXJpdGVQcm9kdWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZmF2b3VyaXRlLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmYXZvdXJpdGU9e2Zhdm91cml0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DZW50ZXJlZENvbnRlbnQ+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL0Zhdm91cml0ZXNMaXN0L0Zhdm91cml0ZXNMaXN0LmpzeCJ9