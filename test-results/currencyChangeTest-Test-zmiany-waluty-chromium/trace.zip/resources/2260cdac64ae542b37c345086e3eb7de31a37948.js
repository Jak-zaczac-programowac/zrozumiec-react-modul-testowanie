import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CategoryMenu/CategoryMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/CategoryMenu/CategoryMenu.module.css";
import { CATEGORIES } from "/src/constants/categories.js";
import { NavLink, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=db5b57d4";
export function CategoryMenu() {
  _s();
  const params = useParams();
  return /* @__PURE__ */ jsxDEV("div", { className: styles.categoryMenu, children: /* @__PURE__ */ jsxDEV("ul", { children: CATEGORIES.map((category) => {
    return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(NavLink, { to: `/${params.gender}/${category.path}`, children: category.categoryName }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.jsx",
      lineNumber: 12,
      columnNumber: 29
    }, this) }, category.path, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.jsx",
      lineNumber: 11,
      columnNumber: 16
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.jsx",
    lineNumber: 9,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_s(CategoryMenu, "+jVsTcECDRo3yq2d7EQxlN9Ixog=", false, function() {
  return [useParams];
});
_c = CategoryMenu;
var _c;
$RefreshReg$(_c, "CategoryMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CategoryMenu/CategoryMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYTRCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWI1QixPQUFPQSxZQUFZO0FBQ25CLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxTQUFTQyxpQkFBaUI7QUFFNUIsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxTQUFTSCxVQUFVO0FBRXpCLFNBQ0ksdUJBQUMsU0FBSSxXQUFXSCxPQUFPTyxjQUNuQixpQ0FBQyxRQUNJTixxQkFBV08sSUFBS0MsY0FBYTtBQUMxQixXQUNJLHVCQUFDLFFBQ0csaUNBQUMsV0FBUSxJQUFLLElBQUdILE9BQU9JLE1BQU8sSUFBR0QsU0FBU0UsSUFBSyxJQUMzQ0YsbUJBQVNHLGdCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhLSCxTQUFTRSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVSLENBQUMsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFUjtBQUFDTixHQWxCZUQsY0FBWTtBQUFBLFVBQ1RELFNBQVM7QUFBQTtBQUFBVSxLQURaVDtBQUFZLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJzdHlsZXMiLCJDQVRFR09SSUVTIiwiTmF2TGluayIsInVzZVBhcmFtcyIsIkNhdGVnb3J5TWVudSIsIl9zIiwicGFyYW1zIiwiY2F0ZWdvcnlNZW51IiwibWFwIiwiY2F0ZWdvcnkiLCJnZW5kZXIiLCJwYXRoIiwiY2F0ZWdvcnlOYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYXRlZ29yeU1lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vQ2F0ZWdvcnlNZW51Lm1vZHVsZS5jc3NcIjtcbmltcG9ydCB7IENBVEVHT1JJRVMgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL2NhdGVnb3JpZXNcIjtcbmltcG9ydCB7IE5hdkxpbmssIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRlZ29yeU1lbnUoKSB7XG4gICAgY29uc3QgcGFyYW1zID0gdXNlUGFyYW1zKCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhdGVnb3J5TWVudX0+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAge0NBVEVHT1JJRVMubWFwKChjYXRlZ29yeSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17Y2F0ZWdvcnkucGF0aH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmsgdG89e2AvJHtwYXJhbXMuZ2VuZGVyfS8ke2NhdGVnb3J5LnBhdGh9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5jYXRlZ29yeU5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9DYXRlZ29yeU1lbnUvQ2F0ZWdvcnlNZW51LmpzeCJ9