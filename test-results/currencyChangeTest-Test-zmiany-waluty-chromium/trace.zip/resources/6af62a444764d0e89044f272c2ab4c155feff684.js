import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/Cart/Cart.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/Cart/Cart.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6df970d1"; const useContext = __vite__cjsImport3_react["useContext"];
import { CartProductsList } from "/src/components/CartProductsList/CartProductsList.jsx";
import { CartSummary } from "/src/components/CartSummary/CartSummary.jsx";
import { FlexContainer } from "/src/components/FlexContainer/FlexContainer.jsx";
import { CartContext } from "/src/contexts/CartContext.js";
export function Cart() {
  _s();
  const [cartItems] = useContext(CartContext);
  return /* @__PURE__ */ jsxDEV(FlexContainer, { children: [
    /* @__PURE__ */ jsxDEV(CartProductsList, { products: cartItems }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/Cart/Cart.jsx",
      lineNumber: 11,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(CartSummary, { products: cartItems }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/Cart/Cart.jsx",
      lineNumber: 12,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/Cart/Cart.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(Cart, "8TtgjICT+9zfxEWbKfpv25AHl3A=");
_c = Cart;
var _c;
$RefreshReg$(_c, "Cart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/views/Cart/Cart.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVlosU0FBU0Esa0JBQWtCO0FBQzNCLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUNyQixnQkFBU0MsT0FBTztBQUFBQyxLQUFBO0FBQ25CLFFBQU0sQ0FBQ0MsU0FBUyxJQUFJUCxXQUFXSSxXQUFXO0FBRTFDLFNBQ0ksdUJBQUMsaUJBQ0c7QUFBQSwyQkFBQyxvQkFBaUIsVUFBVUcsYUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQztBQUFBLElBQ3RDLHVCQUFDLGVBQVksVUFBVUEsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLE9BRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVSO0FBQUNELEdBVGVELE1BQUk7QUFBQUcsS0FBSkg7QUFBSSxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ29udGV4dCIsIkNhcnRQcm9kdWN0c0xpc3QiLCJDYXJ0U3VtbWFyeSIsIkZsZXhDb250YWluZXIiLCJDYXJ0Q29udGV4dCIsIkNhcnQiLCJfcyIsImNhcnRJdGVtcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2FydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ2FydFByb2R1Y3RzTGlzdCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0NhcnRQcm9kdWN0c0xpc3QvQ2FydFByb2R1Y3RzTGlzdFwiO1xuaW1wb3J0IHsgQ2FydFN1bW1hcnkgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9DYXJ0U3VtbWFyeS9DYXJ0U3VtbWFyeVwiO1xuaW1wb3J0IHsgRmxleENvbnRhaW5lciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0ZsZXhDb250YWluZXIvRmxleENvbnRhaW5lclwiO1xuaW1wb3J0IHsgQ2FydENvbnRleHQgfSBmcm9tIFwiLi4vLi4vY29udGV4dHMvQ2FydENvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiBDYXJ0KCkge1xuICAgIGNvbnN0IFtjYXJ0SXRlbXNdID0gdXNlQ29udGV4dChDYXJ0Q29udGV4dCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8RmxleENvbnRhaW5lcj5cbiAgICAgICAgICAgIDxDYXJ0UHJvZHVjdHNMaXN0IHByb2R1Y3RzPXtjYXJ0SXRlbXN9IC8+XG4gICAgICAgICAgICA8Q2FydFN1bW1hcnkgcHJvZHVjdHM9e2NhcnRJdGVtc30gLz5cbiAgICAgICAgPC9GbGV4Q29udGFpbmVyPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvdmlld3MvQ2FydC9DYXJ0LmpzeCJ9