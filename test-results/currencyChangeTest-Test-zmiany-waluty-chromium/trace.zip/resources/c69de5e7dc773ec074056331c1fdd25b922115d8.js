import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Breadcrumbs/Breadcrumbs.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Breadcrumbs/Breadcrumbs.module.css"
const __vite__css = "._breadcrumbs_19bhs_1 {\n    display: flex;\n    justify-content: flex-start;\n    align-items: center;\n    gap: 0.5rem;\n    margin-top: 1rem;\n    margin-bottom: 2rem;\n}\n\n._breadcrumbs_19bhs_1 li a {\n    font-size: 0.75rem;\n    text-transform: uppercase;\n}\n\n._breadcrumbs_19bhs_1 li a.active {\n    font-weight: 700;\n}\n\n._breadcrumbs_19bhs_1 img {\n    transform: rotate(-90deg);\n    margin-left: 0.5rem;\n}\n\n._breadcrumbs_19bhs_1 li:last-of-type img {\n    display: none;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const breadcrumbs = "_breadcrumbs_19bhs_1";
export default {
	breadcrumbs: breadcrumbs
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))