import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Logo/Logo.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Logo/Logo.module.css"
const __vite__css = "._logo_12x2z_1 {\n    text-transform: uppercase;\n    text-align: center;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const logo = "_logo_12x2z_1";
export default {
	logo: logo
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))