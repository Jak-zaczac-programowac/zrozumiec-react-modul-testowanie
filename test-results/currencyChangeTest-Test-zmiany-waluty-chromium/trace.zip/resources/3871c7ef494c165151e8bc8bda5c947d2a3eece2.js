import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/globals.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/styles/globals.css"
const __vite__css = "* {\n    box-sizing: border-box;\n    margin: 0;\n    padding: 0;\n}\n\nli {\n    list-style: none;\n}\n\nh1,\nh2 {\n    font-weight: 700;\n}\n\nh1 {\n    font-size: 2rem;\n}\n\nh2 {\n    font-size: 1.5rem;\n}\n\nh3 {\n    font-size: 1.25rem;\n}\n\nbody {\n    font-size: var(--font-size-default);\n    font-family: var(--font-family-default);\n    color: var(--color-text-default);\n}\n\na {\n    cursor: pointer;\n    text-decoration: none;\n    color: var(--color-text-default);\n}\n\nbutton {\n    cursor: pointer;\n}\n\n#root {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    min-height: 100vh;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))