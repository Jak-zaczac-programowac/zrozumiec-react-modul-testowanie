import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CenteredContent/CenteredContent.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CenteredContent/CenteredContent.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/CenteredContent/CenteredContent.module.css";
export function CenteredContent({
  children
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: styles.wrapper, children }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CenteredContent/CenteredContent.jsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = CenteredContent;
var _c;
$RefreshReg$(_c, "CenteredContent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/CenteredContent/CenteredContent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR1c7QUFIWCxPQUFPQSxvQkFBWTtBQUFBLE1BQThCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUxQyxnQkFBU0MsZ0JBQWdCO0FBQUEsRUFBRUM7QUFBUyxHQUFHO0FBQzFDLFNBQU8sdUJBQUMsU0FBSSxXQUFXRixPQUFPRyxTQUFVRCxZQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBDO0FBQ3JEO0FBQUNFLEtBRmVIO0FBQWUsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlcyIsIkNlbnRlcmVkQ29udGVudCIsImNoaWxkcmVuIiwid3JhcHBlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2VudGVyZWRDb250ZW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL0NlbnRlcmVkQ29udGVudC5tb2R1bGUuY3NzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBDZW50ZXJlZENvbnRlbnQoeyBjaGlsZHJlbiB9KSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMud3JhcHBlcn0+e2NoaWxkcmVufTwvZGl2Pjtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL0NlbnRlcmVkQ29udGVudC9DZW50ZXJlZENvbnRlbnQuanN4In0=