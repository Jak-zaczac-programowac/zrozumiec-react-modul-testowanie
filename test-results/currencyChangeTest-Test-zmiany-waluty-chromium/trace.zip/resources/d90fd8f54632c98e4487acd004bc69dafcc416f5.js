import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/IconMenu/IconMenu.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/IconMenu/IconMenu.module.css"
const __vite__css = "._iconMenu_1mrnj_1 {\n    display: flex;\n    gap: 1rem;\n    padding: 1rem;\n}\n\n._iconMenu_1mrnj_1 li {\n    position: relative;\n}\n\n._numberOfProducts_1mrnj_11 {\n    position: absolute;\n    bottom: -0.5rem;\n    right: -0.5rem;\n\n    background-color: var(--color-yellow);\n    width: 1.25rem;\n    height: 1.25rem;\n    border-radius: 50%;\n\n    font-size: 0.5rem;\n    font-weight: 700;\n\n    display: flex;\n    justify-content: center;\n    align-items: center;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const iconMenu = "_iconMenu_1mrnj_1";
export const numberOfProducts = "_numberOfProducts_1mrnj_11";
export default {
	iconMenu: iconMenu,
	numberOfProducts: numberOfProducts
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))