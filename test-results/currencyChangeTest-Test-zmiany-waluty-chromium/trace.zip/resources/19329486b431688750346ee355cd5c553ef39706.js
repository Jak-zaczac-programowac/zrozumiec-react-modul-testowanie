import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ExpandableMenu/ExpandableMenu.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/ExpandableMenu/ExpandableMenu.module.css"
const __vite__css = "._expandableMenu_cm1v3_1 {\n    width: 11rem;\n    margin-top: 1rem;\n    padding-left: 1rem;\n}\n\n._expandableMenu_cm1v3_1 p {\n    font-weight: 700;\n    margin-bottom: 1rem;\n}\n\n._expandableMenu_cm1v3_1 li {\n    margin-bottom: 0.5rem;\n}\n\n._expandableMenu_cm1v3_1 li a {\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n}\n\n._expandableMenu_cm1v3_1 li ul {\n    padding-left: 2rem;\n    margin-top: 0.5rem;\n}\n\n._expandableMenu_cm1v3_1 a.active {\n    font-weight: 700;\n}\n\n._expanded_cm1v3_31 {\n    transform: rotate(180deg);\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const expandableMenu = "_expandableMenu_cm1v3_1";
export const expanded = "_expanded_cm1v3_31";
export default {
	expandableMenu: expandableMenu,
	expanded: expanded
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))