import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import "/src/styles/theme.css";
import "/src/styles/globals.css";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6df970d1"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import __vite__cjsImport4_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=d26ff0c1"; const ReactDOM = __vite__cjsImport4_reactDom_client.__esModule ? __vite__cjsImport4_reactDom_client.default : __vite__cjsImport4_reactDom_client;
import { createBrowserRouter, RouterProvider } from "/node_modules/.vite/deps/react-router-dom.js?v=db5b57d4";
import { Cart } from "/src/views/Cart/Cart.jsx";
import { Favourites } from "/src/views/Favourites/Favourites.jsx";
import { Layout } from "/src/components/Layout/Layout.jsx";
import { MainPage } from "/src/views/MainPage/MainPage.jsx";
import { ProductsList } from "/src/views/ProductsList/ProductsList.jsx";
import { ProductDetails } from "/src/views/ProductDetails/ProductDetails.jsx";
import { mainPageLoader } from "/src/api/mainPageLoader.js";
import { productListLoader } from "/src/api/productListLoader.js";
import { productLoader } from "/src/api/productLoader.js";
import { addProductToFavourites } from "/src/api/addProductToFavouritesAction.js";
import { favouritesLoader } from "/src/api/favouritesLoader.js";
import { deleteFavouriteAction } from "/src/api/deleteFavouriteAction.js";
const router = createBrowserRouter([{
  path: "/add-to-favourites/:productId",
  action: addProductToFavourites
}, {
  path: "/delete-from-favourites/:favouriteId",
  action: deleteFavouriteAction
}, {
  path: "",
  element: /* @__PURE__ */ jsxDEV(Layout, {}, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
    lineNumber: 26,
    columnNumber: 12
  }, this),
  children: [{
    path: "/koszyk",
    element: /* @__PURE__ */ jsxDEV(Cart, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
      lineNumber: 29,
      columnNumber: 14
    }, this)
  }, {
    path: "/ulubione",
    element: /* @__PURE__ */ jsxDEV(Favourites, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
      lineNumber: 32,
      columnNumber: 14
    }, this),
    loader: favouritesLoader
  }, {
    path: "/:gender?",
    element: /* @__PURE__ */ jsxDEV(MainPage, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
      lineNumber: 36,
      columnNumber: 14
    }, this),
    loader: mainPageLoader
  }, {
    path: "/:gender/:category/:subcategory?",
    element: /* @__PURE__ */ jsxDEV(ProductsList, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
      lineNumber: 40,
      columnNumber: 14
    }, this),
    loader: productListLoader
  }, {
    path: "/:gender/:category/:subcategory/:productId",
    element: /* @__PURE__ */ jsxDEV(ProductDetails, {}, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
      lineNumber: 44,
      columnNumber: 14
    }, this),
    loader: productLoader
  }]
}]);
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(RouterProvider, { router }, void 0, false, {
  fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
  lineNumber: 49,
  columnNumber: 9
}, this) }, void 0, false, {
  fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/main.jsx",
  lineNumber: 48,
  columnNumber: 61
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJpQjtBQTdCakIsT0FBTztBQUNQLE9BQU87QUFDUCxPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsU0FBU0MscUJBQXFCQyxzQkFBc0I7QUFDcEQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDZCQUE2QjtBQUV0QyxNQUFNQyxTQUFTZCxvQkFBb0IsQ0FDL0I7QUFBQSxFQUNJZSxNQUFNO0FBQUEsRUFDTkMsUUFBUUw7QUFDWixHQUNBO0FBQUEsRUFDSUksTUFBTTtBQUFBLEVBQ05DLFFBQVFIO0FBQ1osR0FDQTtBQUFBLEVBQ0lFLE1BQU07QUFBQSxFQUNORSxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPO0FBQUEsRUFDaEJDLFVBQVUsQ0FDTjtBQUFBLElBQ0lILE1BQU07QUFBQSxJQUNORSxTQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLO0FBQUEsRUFDbEIsR0FDQTtBQUFBLElBQ0lGLE1BQU07QUFBQSxJQUNORSxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVztBQUFBLElBQ3BCRSxRQUFRUDtBQUFBQSxFQUNaLEdBQ0E7QUFBQSxJQUNJRyxNQUFNO0FBQUEsSUFDTkUsU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ2xCRSxRQUFRWDtBQUFBQSxFQUNaLEdBQ0E7QUFBQSxJQUNJTyxNQUFNO0FBQUEsSUFDTkUsU0FBUyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxJQUN0QkUsUUFBUVY7QUFBQUEsRUFDWixHQUNBO0FBQUEsSUFDSU0sTUFBTTtBQUFBLElBQ05FLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFDeEJFLFFBQVFUO0FBQUFBLEVBQ1osQ0FBQztBQUVULENBQUMsQ0FDSjtBQUVEWCxTQUFTcUIsV0FBV0MsU0FBU0MsZUFBZSxNQUFNLENBQUMsRUFBRUMsT0FDakQsdUJBQUMsTUFBTSxZQUFOLEVBQ0csaUNBQUMsa0JBQWUsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFnQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUEsQ0FDSiIsIm5hbWVzIjpbIlJlYWN0IiwiUmVhY3RET00iLCJjcmVhdGVCcm93c2VyUm91dGVyIiwiUm91dGVyUHJvdmlkZXIiLCJDYXJ0IiwiRmF2b3VyaXRlcyIsIkxheW91dCIsIk1haW5QYWdlIiwiUHJvZHVjdHNMaXN0IiwiUHJvZHVjdERldGFpbHMiLCJtYWluUGFnZUxvYWRlciIsInByb2R1Y3RMaXN0TG9hZGVyIiwicHJvZHVjdExvYWRlciIsImFkZFByb2R1Y3RUb0Zhdm91cml0ZXMiLCJmYXZvdXJpdGVzTG9hZGVyIiwiZGVsZXRlRmF2b3VyaXRlQWN0aW9uIiwicm91dGVyIiwicGF0aCIsImFjdGlvbiIsImVsZW1lbnQiLCJjaGlsZHJlbiIsImxvYWRlciIsImNyZWF0ZVJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sInNvdXJjZXMiOlsibWFpbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi9zdHlsZXMvdGhlbWUuY3NzXCI7XG5pbXBvcnQgXCIuL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgeyBjcmVhdGVCcm93c2VyUm91dGVyLCBSb3V0ZXJQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBDYXJ0IH0gZnJvbSBcIi4vdmlld3MvQ2FydC9DYXJ0XCI7XG5pbXBvcnQgeyBGYXZvdXJpdGVzIH0gZnJvbSBcIi4vdmlld3MvRmF2b3VyaXRlcy9GYXZvdXJpdGVzXCI7XG5pbXBvcnQgeyBMYXlvdXQgfSBmcm9tIFwiLi9jb21wb25lbnRzL0xheW91dC9MYXlvdXRcIjtcbmltcG9ydCB7IE1haW5QYWdlIH0gZnJvbSBcIi4vdmlld3MvTWFpblBhZ2UvTWFpblBhZ2VcIjtcbmltcG9ydCB7IFByb2R1Y3RzTGlzdCB9IGZyb20gXCIuL3ZpZXdzL1Byb2R1Y3RzTGlzdC9Qcm9kdWN0c0xpc3RcIjtcbmltcG9ydCB7IFByb2R1Y3REZXRhaWxzIH0gZnJvbSBcIi4vdmlld3MvUHJvZHVjdERldGFpbHMvUHJvZHVjdERldGFpbHNcIjtcbmltcG9ydCB7IG1haW5QYWdlTG9hZGVyIH0gZnJvbSBcIi4vYXBpL21haW5QYWdlTG9hZGVyXCI7XG5pbXBvcnQgeyBwcm9kdWN0TGlzdExvYWRlciB9IGZyb20gXCIuL2FwaS9wcm9kdWN0TGlzdExvYWRlclwiO1xuaW1wb3J0IHsgcHJvZHVjdExvYWRlciB9IGZyb20gXCIuL2FwaS9wcm9kdWN0TG9hZGVyXCI7XG5pbXBvcnQgeyBhZGRQcm9kdWN0VG9GYXZvdXJpdGVzIH0gZnJvbSBcIi4vYXBpL2FkZFByb2R1Y3RUb0Zhdm91cml0ZXNBY3Rpb25cIjtcbmltcG9ydCB7IGZhdm91cml0ZXNMb2FkZXIgfSBmcm9tIFwiLi9hcGkvZmF2b3VyaXRlc0xvYWRlclwiO1xuaW1wb3J0IHsgZGVsZXRlRmF2b3VyaXRlQWN0aW9uIH0gZnJvbSBcIi4vYXBpL2RlbGV0ZUZhdm91cml0ZUFjdGlvblwiO1xuXG5jb25zdCByb3V0ZXIgPSBjcmVhdGVCcm93c2VyUm91dGVyKFtcbiAgICB7XG4gICAgICAgIHBhdGg6IFwiL2FkZC10by1mYXZvdXJpdGVzLzpwcm9kdWN0SWRcIixcbiAgICAgICAgYWN0aW9uOiBhZGRQcm9kdWN0VG9GYXZvdXJpdGVzLFxuICAgIH0sXG4gICAge1xuICAgICAgICBwYXRoOiBcIi9kZWxldGUtZnJvbS1mYXZvdXJpdGVzLzpmYXZvdXJpdGVJZFwiLFxuICAgICAgICBhY3Rpb246IGRlbGV0ZUZhdm91cml0ZUFjdGlvbixcbiAgICB9LFxuICAgIHtcbiAgICAgICAgcGF0aDogXCJcIixcbiAgICAgICAgZWxlbWVudDogPExheW91dCAvPixcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBwYXRoOiBcIi9rb3N6eWtcIixcbiAgICAgICAgICAgICAgICBlbGVtZW50OiA8Q2FydCAvPixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcGF0aDogXCIvdWx1YmlvbmVcIixcbiAgICAgICAgICAgICAgICBlbGVtZW50OiA8RmF2b3VyaXRlcyAvPixcbiAgICAgICAgICAgICAgICBsb2FkZXI6IGZhdm91cml0ZXNMb2FkZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6IFwiLzpnZW5kZXI/XCIsXG4gICAgICAgICAgICAgICAgZWxlbWVudDogPE1haW5QYWdlIC8+LFxuICAgICAgICAgICAgICAgIGxvYWRlcjogbWFpblBhZ2VMb2FkZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6IFwiLzpnZW5kZXIvOmNhdGVnb3J5LzpzdWJjYXRlZ29yeT9cIixcbiAgICAgICAgICAgICAgICBlbGVtZW50OiA8UHJvZHVjdHNMaXN0IC8+LFxuICAgICAgICAgICAgICAgIGxvYWRlcjogcHJvZHVjdExpc3RMb2FkZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6IFwiLzpnZW5kZXIvOmNhdGVnb3J5LzpzdWJjYXRlZ29yeS86cHJvZHVjdElkXCIsXG4gICAgICAgICAgICAgICAgZWxlbWVudDogPFByb2R1Y3REZXRhaWxzIC8+LFxuICAgICAgICAgICAgICAgIGxvYWRlcjogcHJvZHVjdExvYWRlcixcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbl0pO1xuXG5SZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm9vdFwiKSkucmVuZGVyKFxuICAgIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgICAgICA8Um91dGVyUHJvdmlkZXIgcm91dGVyPXtyb3V0ZXJ9PjwvUm91dGVyUHJvdmlkZXI+XG4gICAgPC9SZWFjdC5TdHJpY3RNb2RlPlxuKTtcbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9tYWluLmpzeCJ9