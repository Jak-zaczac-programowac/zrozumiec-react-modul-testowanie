import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Product/Product.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import styles from "/src/components/Product/Product.module.css";
import { Link, useFetcher } from "/node_modules/.vite/deps/react-router-dom.js?v=db5b57d4";
import { Price } from "/src/components/Price/Price.jsx";
const ENDPOINT_TO_PATH_MAPPING = {
  men: "mezczyzna",
  women: "kobieta",
  children: "dziecko"
};
export function Product({
  product
}) {
  _s();
  const {
    Form
  } = useFetcher();
  return /* @__PURE__ */ jsxDEV(Link, { to: `/${ENDPOINT_TO_PATH_MAPPING[product.gender]}/${product.category}/${product.subcategory}/${product.id}`, className: styles.product, children: [
    /* @__PURE__ */ jsxDEV("img", { src: product.photos[0] }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 18,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { children: product.productName }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 19,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: /* @__PURE__ */ jsxDEV(Price, { product }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 21,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 20,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Form, { onClick: (e) => {
      e.stopPropagation();
    }, method: "POST", action: `/add-to-favourites/${product.id}`, children: /* @__PURE__ */ jsxDEV("button", { children: /* @__PURE__ */ jsxDEV("div", { className: styles.heart }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 27,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 26,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
      lineNumber: 23,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_s(Product, "UXyIbjkGCCZfcpydX8Glvf3h2bY=", false, function() {
  return [useFetcher];
});
_c = Product;
var _c;
$RefreshReg$(_c, "Product");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Product/Product.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CWixPQUFPQSxZQUFZO0FBQ25CLFNBQVNDLE1BQU1DLGtCQUFrQjtBQUNqQyxTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLDJCQUEyQjtBQUFBLEVBQzdCQyxLQUFLO0FBQUEsRUFDTEMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFDZDtBQUVPLGdCQUFTQyxRQUFRO0FBQUEsRUFBRUM7QUFBUSxHQUFHO0FBQUFDLEtBQUE7QUFDakMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQUssSUFBSVQsV0FBVztBQUM1QixTQUNJLHVCQUFDLFFBQ0csSUFBSyxJQUFHRSx5QkFBeUJLLFFBQVFHLE1BQU0sQ0FBRSxJQUM3Q0gsUUFBUUksUUFDWCxJQUFHSixRQUFRSyxXQUFZLElBQUdMLFFBQVFNLEVBQUcsSUFDdEMsV0FBV2YsT0FBT1MsU0FFbEI7QUFBQSwyQkFBQyxTQUFJLEtBQUtBLFFBQVFPLE9BQU8sQ0FBQyxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsSUFDNUIsdUJBQUMsUUFBSVAsa0JBQVFRLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLE9BQ0csaUNBQUMsU0FBTSxXQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxRQUNHLFNBQVVDLE9BQU07QUFDWkEsUUFBRUMsZ0JBQWdCO0FBQUEsSUFDdEIsR0FDQSxRQUFPLFFBQ1AsUUFBUyxzQkFBcUJWLFFBQVFNLEVBQUcsSUFFekMsaUNBQUMsWUFDRyxpQ0FBQyxTQUFJLFdBQVdmLE9BQU9vQixTQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFUjtBQUFDVixHQTNCZUYsU0FBTztBQUFBLFVBQ0ZOLFVBQVU7QUFBQTtBQUFBbUIsS0FEZmI7QUFBTyxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiTGluayIsInVzZUZldGNoZXIiLCJQcmljZSIsIkVORFBPSU5UX1RPX1BBVEhfTUFQUElORyIsIm1lbiIsIndvbWVuIiwiY2hpbGRyZW4iLCJQcm9kdWN0IiwicHJvZHVjdCIsIl9zIiwiRm9ybSIsImdlbmRlciIsImNhdGVnb3J5Iiwic3ViY2F0ZWdvcnkiLCJpZCIsInBob3RvcyIsInByb2R1Y3ROYW1lIiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsImhlYXJ0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9kdWN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuL1Byb2R1Y3QubW9kdWxlLmNzc1wiO1xuaW1wb3J0IHsgTGluaywgdXNlRmV0Y2hlciB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBQcmljZSB9IGZyb20gXCIuLi9QcmljZS9QcmljZVwiO1xuXG5jb25zdCBFTkRQT0lOVF9UT19QQVRIX01BUFBJTkcgPSB7XG4gICAgbWVuOiBcIm1lemN6eXpuYVwiLFxuICAgIHdvbWVuOiBcImtvYmlldGFcIixcbiAgICBjaGlsZHJlbjogXCJkemllY2tvXCIsXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdCh7IHByb2R1Y3QgfSkge1xuICAgIGNvbnN0IHsgRm9ybSB9ID0gdXNlRmV0Y2hlcigpO1xuICAgIHJldHVybiAoXG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz17YC8ke0VORFBPSU5UX1RPX1BBVEhfTUFQUElOR1twcm9kdWN0LmdlbmRlcl19LyR7XG4gICAgICAgICAgICAgICAgcHJvZHVjdC5jYXRlZ29yeVxuICAgICAgICAgICAgfS8ke3Byb2R1Y3Quc3ViY2F0ZWdvcnl9LyR7cHJvZHVjdC5pZH1gfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMucHJvZHVjdH1cbiAgICAgICAgPlxuICAgICAgICAgICAgPGltZyBzcmM9e3Byb2R1Y3QucGhvdG9zWzBdfSAvPlxuICAgICAgICAgICAgPGgzPntwcm9kdWN0LnByb2R1Y3ROYW1lfTwvaDM+XG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICA8UHJpY2UgcHJvZHVjdD17cHJvZHVjdH0gLz5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxGb3JtXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIG1ldGhvZD1cIlBPU1RcIlxuICAgICAgICAgICAgICAgIGFjdGlvbj17YC9hZGQtdG8tZmF2b3VyaXRlcy8ke3Byb2R1Y3QuaWR9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8YnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmhlYXJ0fT48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgPC9MaW5rPlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9rYWNwZXJzb2tvbG93c2tpL2Rldi96cm96dW1pZWMtcmVhY3QtbW9kdWwtcHJha3R5Y3pueS1wcm9qZWt0L2Zyb250LWVuZC9zcmMvY29tcG9uZW50cy9Qcm9kdWN0L1Byb2R1Y3QuanN4In0=