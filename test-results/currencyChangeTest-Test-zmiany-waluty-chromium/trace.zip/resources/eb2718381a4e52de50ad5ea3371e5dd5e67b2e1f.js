import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FlexContainer/FlexContainer.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FlexContainer/FlexContainer.module.css"
const __vite__css = "._flexContainer_fyqm5_1 {\n    display: flex;\n    gap: 1rem;\n    width: 100%;\n    max-width: 100rem;\n    margin: 0 auto;\n    align-items: flex-start;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const flexContainer = "_flexContainer_fyqm5_1";
export default {
	flexContainer: flexContainer
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))