import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FullWidthButton/FullWidthButton.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FullWidthButton/FullWidthButton.module.css"
const __vite__css = "._button_2ggf2_1 {\n    border: none;\n    background: none;\n    width: 100%;\n    padding: 1rem 0;\n    color: var(--color-white);\n    text-transform: uppercase;\n    background-color: var(--color-theme-main);\n    font-weight: 700;\n}\n\n._black_2ggf2_12 {\n    background-color: var(--color-text-default);\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const button = "_button_2ggf2_1";
export const black = "_black_2ggf2_12";
export default {
	button: button,
	black: black
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))