import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Hero/Hero.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Hero/Hero.module.css"
const __vite__css = "._hero_7asvi_1 {\n    width: 100%;\n    height: 500px;\n    background-size: cover;\n}\n\n._contentWrapper_7asvi_7 {\n    margin-top: 5rem;\n    padding: 3rem 5rem;\n    display: inline-block;\n    background: rgba(255, 255, 255, 0.5);\n}\n\n._contentWrapper_7asvi_7 p {\n    margin-top: 1rem;\n    margin-bottom: 2rem;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const hero = "_hero_7asvi_1";
export const contentWrapper = "_contentWrapper_7asvi_7";
export default {
	hero: hero,
	contentWrapper: contentWrapper
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))