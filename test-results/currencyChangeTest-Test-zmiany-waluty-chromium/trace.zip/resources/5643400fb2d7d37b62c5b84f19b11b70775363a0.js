import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/theme.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/styles/theme.css"
const __vite__css = "body {\n    --font-size-default: 16px;\n    --font-family-default: Helvetica, Arial, sans-serif;\n\n    --color-text-default: #222020;\n    --color-text-grey: #7a7a7a;\n    --color-yellow: #ffde00;\n    --color-white: #ffffff;\n    --color-grey: #f4f4f4;\n    --color-theme-main: #056943;\n    --color-price: #c60c0c;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))