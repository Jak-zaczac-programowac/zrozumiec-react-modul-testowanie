import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Pagination/Pagination.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Pagination/Pagination.module.css"
const __vite__css = "._pagination_kc53l_1 {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    gap: 1rem;\n    margin: 2rem 0;\n}\n\n._pagination_kc53l_1 li {\n    cursor: pointer;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const pagination = "_pagination_kc53l_1";
export default {
	pagination: pagination
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))