import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FlexContainer/FlexContainer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df970d1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FlexContainer/FlexContainer.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styles from "/src/components/FlexContainer/FlexContainer.module.css";
export function FlexContainer({
  children
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: styles.flexContainer, children }, void 0, false, {
    fileName: "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FlexContainer/FlexContainer.jsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = FlexContainer;
var _c;
$RefreshReg$(_c, "FlexContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/FlexContainer/FlexContainer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR1c7QUFIWCxPQUFPQSxvQkFBWTtBQUFBLE1BQTRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUV4QyxnQkFBU0MsY0FBYztBQUFBLEVBQUVDO0FBQVMsR0FBRztBQUN4QyxTQUFPLHVCQUFDLFNBQUksV0FBV0YsT0FBT0csZUFBZ0JELFlBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0Q7QUFDM0Q7QUFBQ0UsS0FGZUg7QUFBYSxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVzIiwiRmxleENvbnRhaW5lciIsImNoaWxkcmVuIiwiZmxleENvbnRhaW5lciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRmxleENvbnRhaW5lci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9GbGV4Q29udGFpbmVyLm1vZHVsZS5jc3NcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEZsZXhDb250YWluZXIoeyBjaGlsZHJlbiB9KSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZmxleENvbnRhaW5lcn0+e2NoaWxkcmVufTwvZGl2Pjtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2thY3BlcnNva29sb3dza2kvZGV2L3pyb3p1bWllYy1yZWFjdC1tb2R1bC1wcmFrdHljem55LXByb2pla3QvZnJvbnQtZW5kL3NyYy9jb21wb25lbnRzL0ZsZXhDb250YWluZXIvRmxleENvbnRhaW5lci5qc3gifQ==