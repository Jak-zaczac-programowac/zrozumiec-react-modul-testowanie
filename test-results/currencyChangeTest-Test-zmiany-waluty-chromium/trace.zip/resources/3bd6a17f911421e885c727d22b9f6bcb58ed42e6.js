import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Details/Details.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/kacpersokolowski/dev/zrozumiec-react-modul-praktyczny-projekt/front-end/src/components/Details/Details.module.css"
const __vite__css = "._details_mm0vc_1 {\n    width: 100%;\n    padding-right: 1rem;\n}\n\n._productName_mm0vc_6 {\n    margin: 0.5rem 0;\n    font-weight: 700;\n}\n\n._price_mm0vc_11 {\n    color: var(--color-price);\n    font-size: 1.5rem;\n    margin-bottom: 2rem;\n}\n\n._extraInfo_mm0vc_17 {\n    margin-top: 2rem;\n}\n\n._extraInfo_mm0vc_17 li {\n    display: flex;\n    align-items: center;\n    justify-content: flex-start;\n    gap: 1rem;\n    margin-bottom: 1rem;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
export const details = "_details_mm0vc_1";
export const productName = "_productName_mm0vc_6";
export const price = "_price_mm0vc_11";
export const extraInfo = "_extraInfo_mm0vc_17";
export default {
	details: details,
	productName: productName,
	price: price,
	extraInfo: extraInfo
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))